export * from './producer-readers.js';
export { parseProducerContracts } from './producer-contracts.js';
export type { ProducerContracts } from './producer-contracts.js';

// Existing session APIs retain their open option/result shapes. The 0.3.0
// producer readers above provide evidence-specific types without narrowing them.
export function connect(options?: Record<string, any>): Promise<any>;
export class HealthRouter {
  constructor(options?: Record<string, any>);
  [key: string]: any;
}
export function deriveWorkflowActionId(options: Record<string, any>): string;
