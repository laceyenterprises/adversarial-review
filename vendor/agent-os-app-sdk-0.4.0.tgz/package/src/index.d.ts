export * from './producer-readers.js';
export { parseProducerContracts } from './producer-contracts.js';
export type { ProducerContracts } from './producer-contracts.js';

// Existing session APIs retain their open option/result shapes. The 0.3.0
// producer readers above provide evidence-specific types without narrowing them.
export function connect(options?: Record<string, any>): Promise<AppSession>;
export class HealthRouter {
  constructor(options?: Record<string, any>);
  [key: string]: any;
}
export function deriveWorkflowActionId(options: Record<string, any>): string;

/** SDK 0.4.0: read-only evidence for a request owned by the session app. */
export interface EvalUsageOptions {
  view?: 'runs' | 'controls' | 'transcript_metrics';
  run_id?: string;
  limit?: number;
  offset?: number;
}
export interface EvalPage {
  limit: number;
  offset: number;
  has_more: boolean;
  next_offset: number | null;
  truncated: boolean;
}
export interface EvalUsageResult {
  schema_version: 1;
  status: 'found' | 'not_found' | 'unavailable';
  reason?: string;
  app_id?: string;
  request_id?: string;
  launch?: Record<string, unknown>;
  items?: Array<Record<string, unknown>>;
  page?: EvalPage;
  cost?: Record<string, number | null> | null;
  usage?: Record<string, number | boolean | null> | null;
  aggregate_complete?: boolean;
  [key: string]: unknown;
}
export interface AppSession {
  evalUsage(requestId: string, options?: EvalUsageOptions): Promise<EvalUsageResult>;
  evalRequests(options?: Pick<EvalUsageOptions, 'limit' | 'offset'>): Promise<EvalUsageResult>;
  [key: string]: any;
}
