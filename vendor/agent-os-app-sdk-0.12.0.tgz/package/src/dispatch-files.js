/** Dispatch evidence remains partial when files are absent or still publishing. */
export function readDispatchFiles(value) {
  const unavailable = { available: false, reason: 'dispatch-files-unavailable' };
  if (!value || value.schema_version !== 1 || value.scope_complete !== false || value.mutation_authority !== false) return unavailable;
  if (value.status === 'not_found' && value.metadata === null && value.log === null) return {available: true, found: false, metadata: null, log: null};
  if (value.status !== 'found' || typeof value.launchRequestId !== 'string') return unavailable;
  const {metadata, log} = value;
  if (!metadata || !log || log.redacted !== true || !['found', 'missing', 'unavailable'].includes(log.status)) return unavailable;
  if (metadata.status === 'found' && (metadata.launchRequestId !== value.launchRequestId || metadata.runId !== value.runId)) return unavailable;
  if (log.status === 'found' && (typeof log.text !== 'string' || new TextEncoder().encode(log.text).length > 262144
    || ['offset', 'nextOffset', 'size'].some(k => !Number.isSafeInteger(log[k]) || log[k] < 0)
    || log.offset > log.nextOffset || log.nextOffset > log.size
    || ['complete', 'truncated', 'reset'].some(k => typeof log[k] !== 'boolean'))) return unavailable;
  return {available: true, found: true, metadata, log};
}
