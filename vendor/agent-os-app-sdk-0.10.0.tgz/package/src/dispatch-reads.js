/** Interpret the producer-owned dispatch lookup envelope without granting policy authority. */
export function readDispatchLookupResult(value) {
  const unavailable = { available: false, reason: 'dispatch-read-unavailable' };
  if (value?.schema_version !== 1 || value.complete !== true
    || !['found', 'not_found'].includes(value.status)
    || !Array.isArray(value.items) || value.items.length > 1000
    || !Array.isArray(value.roots) || !Array.isArray(value.retry_edges) || value.retry_edges.length > 1000) return unavailable;
  const ids = new Set();
  for (const row of value.items) {
    if (!row || typeof row.launch_request_id !== 'string' || !row.launch_request_id
      || ids.has(row.launch_request_id)) return unavailable;
    ids.add(row.launch_request_id);
  }
  if (value.roots.some(id => !ids.has(id))
    || (value.status === 'not_found' && (ids.size || value.roots.length))
    || (value.status === 'found' && !value.roots.length)
    || value.retry_edges.some(edge => !edge || !ids.has(edge.parent) || !ids.has(edge.child))) return unavailable;
  return { available: true, found: value.status === 'found', items: value.items,
    roots: value.roots, retryEdges: value.retry_edges };
}

/** Keep producer ordering; cycles and terminal ancestors never duplicate the root. */
export function dispatchRetryDescendants(items, edges, launchRequestId) {
  const descendants = new Set([launchRequestId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of edges) {
      if (descendants.has(edge.parent) && !descendants.has(edge.child)) {
        descendants.add(edge.child); changed = true;
      }
    }
  }
  return items.filter(row => row.launch_request_id !== launchRequestId && descendants.has(row.launch_request_id));
}

/** Bounded observation page; partial pages and unknown ownership grant no authority. */
export function readWorkerObservations(value) {
  const unavailable = { available: false, reason: 'worker-observation-unavailable' };
  if (value?.schema_version !== 1 || !['workers', 'sessions', 'provenance', 'completions', 'dag_runs', 'execution_verdicts', 'hardening_contracts', 'hardening_records', 'hardening_exposure'].includes(value.observation)
    || !['found', 'not_found', 'not_live'].includes(value.status) || !Array.isArray(value.items)
    || value.items.length > 100 || typeof value.complete !== 'boolean'
    || value.mutation_authority !== false || value.scope_complete !== false
    || (value.complete ? value.next_offset !== null : !Number.isInteger(value.next_offset) || value.next_offset < 1)
    || (value.status === 'not_found' && value.items.length)
    || (value.status === 'not_live' && (value.observation !== 'dag_runs' || value.items.length || value.complete !== true || value.next_offset !== null))) return unavailable;
  const identity = {workers:'run_id', sessions:'session_id', provenance:'launch_request_id', completions:'completion_id', dag_runs:'run_id', execution_verdicts:'verdictId', hardening_contracts:'contract_id', hardening_records:'record_id', hardening_exposure:'contract_id'}[value.observation];
  const ids = new Set();
  for (const row of value.items) {
    if (!row || typeof row[identity] !== 'string' || !row[identity] || ids.has(row[identity])) return unavailable;
    ids.add(row[identity]);
  }
  return { available: true, found: value.status === 'found', items: value.items,
    ...(value.status === 'not_live' ? { notLive: true } : {}),
    complete: value.complete, nextOffset: value.next_offset, scopeComplete: false, mutationAuthority: false };
}

/** Review observations share the versioned bounded page contract. */
export const readReviewObservations = readWorkerObservations;
