/** Evidence only: these results grant no routing, retry or publication authority. */
export interface LaunchStatusEvidence {
  status: string | null;
  terminal: boolean;
  succeeded: boolean;
  blockedNeedsDecision: boolean;
  diagnostic: string | null;
}
export interface DispatchReceiptEvidence {
  payload: any;
  rawIdentity: unknown;
  launchRequestId: string | null;
  identityDiagnostic: string | null;
  status: LaunchStatusEvidence;
}
export interface DispatchStatusEvidence<T = unknown> {
  payload: T;
  status: string | null;
  terminal: boolean;
  succeeded: boolean;
  blockedNeedsDecision: boolean;
  diagnostics: string[];
}
export interface BrokerProviderEvidence {
  ready: unknown;
  canServe: unknown;
  legacyReady: unknown;
  diagnostics: string[];
}
export interface BrokerEvidence<T = unknown> {
  payload: T;
  providers: Record<string, BrokerProviderEvidence>;
  diagnostics: string[];
}
export interface QuotaMeasurementEvidence {
  status: string;
  percentRemaining: number;
  [key: string]: unknown;
}
export interface WeeklyEvidence {
  measurement: QuotaMeasurementEvidence | null;
  source: 'weeklyMeasurement' | 'measurement' | null;
  diagnostics: string[];
}
export interface FleetEvidence<T = unknown> {
  payload: T;
  providerStatuses: unknown[];
  reserveFloors: Record<string, WeeklyEvidence>;
  diagnostics: string[];
}
export interface AdapterEvidence<T = unknown> {
  payload: T;
  accepted: boolean;
  complete: boolean | null;
  diagnostics: string[];
}
export interface PrCreateEvidence {
  accepted: boolean;
  url: unknown;
  output: unknown;
  diagnostics: string[];
}
export interface PublicationEvidence<T = unknown> {
  payload: T;
  surface: string;
  diagnostics: string[];
}
export const LAUNCH_REQUEST_STATUSES: Set<string>;
export const TERMINAL_LAUNCH_REQUEST_STATUSES: Set<string>;
export function assertTerminalLaunchPolicy(statuses: Iterable<string>): void;
export function diagnosticValue(value?: unknown): string;
export function boundedDiagnostics(values: Iterable<unknown> | null | undefined): string[];
export function readLaunchRequestStatus(value?: unknown): LaunchStatusEvidence;
export function readDispatchReceipt(value: unknown, options?: { identityFields?: string[]; allowNonObject?: boolean }): DispatchReceiptEvidence;
export function readDispatchStatus<T>(payload: T): DispatchStatusEvidence<T>;
export function readBrokerProvider(payload: unknown, provider: string): BrokerProviderEvidence;
export function readBrokerReadyz<T>(payload: T, providers?: string[]): BrokerEvidence<T>;
export function reserveFloorWeeklyMeasurement(floor: unknown): QuotaMeasurementEvidence | null;
export function readReserveFloorWeeklyEvidence(floor: unknown, credential: string): WeeklyEvidence;
export function readFleetQuota<T>(payload: T): FleetEvidence<T>;
export function readAdapterResultEnvelope<T>(payload: T): AdapterEvidence<T>;
export { readAdapterResultEnvelope as readAdapterReceipt };
export function readPrCreateReceipt(payload: unknown): PrCreateEvidence;
export function readPublicationReceipt<T>(payload: T, surface?: string): PublicationEvidence<T>;
export function parseDispatchJsonOutput(stdout: unknown): any;
export function parseHqJsonObject(text: unknown, label: string): any;
export function parseHqDispatchStatus(stdout: unknown, options?: { normalize?: boolean }): any;
export function quotaAccountDiagnostics(payload: unknown, options: { provider: string; authPath: string; cap: { available?: boolean; modelState?: string; model?: string; capped?: boolean; capSource?: string }; reserve?: boolean }): string[];

/** Raw producer facts survive unchanged, including future fields and states. */
export interface ProjectionEvidence<T = any> {
  payload: T;
  diagnostics: string[];
}
export interface LaunchProjectionEvidence<T = any> extends ProjectionEvidence<T> {
  launch: LaunchStatusEvidence | null;
}
export interface ProjectionPageEvidence<T = unknown> extends ProjectionEvidence<T> {
  available: boolean | null;
  /** null when the producer supplies no evidence-completeness field (Asks). */
  complete: boolean | null;
  nextCursor: string | null;
  isFinalPage: boolean | null;
}
export interface PackRunsPageEvidence<T = unknown> extends ProjectionPageEvidence<T> {
  runs: ProjectionEvidence[];
}
export interface PackRunDetailEvidence<T = unknown> extends ProjectionPageEvidence<T> {
  run: ProjectionEvidence;
  steps: LaunchProjectionEvidence[];
}
export interface AsksPageEvidence<T = unknown> extends ProjectionPageEvidence<T> {
  items: LaunchProjectionEvidence[];
}
export function readPackRun<T>(payload: T): ProjectionEvidence<T>;
export function readPackStep<T>(payload: T): LaunchProjectionEvidence<T>;
export function readAsk<T>(payload: T): LaunchProjectionEvidence<T>;
export function readPackRunsPage<T>(payload: T): PackRunsPageEvidence<T>;
export function readPackRunDetail<T>(payload: T): PackRunDetailEvidence<T>;
export function readAsksPage<T>(payload: T): AsksPageEvidence<T>;

export interface DispatchFailureModeEvidence {
  payload: unknown;
  terminalState: string | null;
  failureMode: string | null;
  retryEligible: boolean;
  diagnostics: string[];
}
export function readDispatchFailureMode(payload: unknown, launchRequestId?: string | null): DispatchFailureModeEvidence;
export function readDispatchRefusal(payload: unknown, launchKey: string): { payload: unknown; receipt: Record<string, unknown> | null; diagnostics: string[] };

export const DISPATCH_REFUSAL_EXIT_CODE: number;
