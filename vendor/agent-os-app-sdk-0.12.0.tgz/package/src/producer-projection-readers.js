// Browser projection readers share the core with daemon/CLI readers.
import { bundle, object, readLaunchRequestStatus, projectionDiagnostics } from './producer-reader-core.js';

function readProjection(payload, schema, surface) {
  return { payload, diagnostics: projectionDiagnostics(payload, schema, '$', `operator_console.${surface}`) };
}

/** Read a run without deriving movement, deployment or completion. @param {any} payload */
export function readPackRun(payload) {
  return readProjection(payload, bundle.producers['pack-runs'].schema.properties.runs.items, 'pack-runs');
}

/** Launch meaning is delegated to the existing launch reader. @param {any} payload */
export function readPackStep(payload) {
  const result = readProjection(payload, bundle.producers['pack-run-detail'].schema.properties.steps.items, 'pack-run-detail');
  const rawStatus = object(payload?.launch) ? payload.launch.rawStatus : null;
  const launch = rawStatus == null ? null : readLaunchRequestStatus(rawStatus);
  if (launch?.diagnostic) result.diagnostics.push(`operator_console.pack-run-detail: $.launch.rawStatus: ${launch.diagnostic}`);
  return { ...result, launch };
}

/** Missing recommendations and unknown kinds remain raw evidence. @param {any} payload */
export function readAsk(payload) {
  const result = readProjection(payload, bundle.producers.asks.schema.properties.items.items, 'asks');
  const launch = payload?.launchStatus == null ? null : readLaunchRequestStatus(payload.launchStatus);
  if (launch?.diagnostic) result.diagnostics.push(`operator_console.asks: $.launchStatus: ${launch.diagnostic}`);
  if (typeof payload?.recommended === 'string' && Array.isArray(payload?.options) && !payload.options.some(option => option?.optionId === payload.recommended)) result.diagnostics.push('operator_console.asks: $.recommended does not identify a supplied option');
  return { ...result, launch };
}

function readProjectionPage(payload, surface, rows, reader) {
  const result = readProjection(payload, bundle.producers[surface].schema, surface);
  const nextCursor = typeof payload?.nextCursor === 'string' && payload.nextCursor ? payload.nextCursor : null;
  const isFinalPage = typeof payload?.isFinalPage === 'boolean' ? payload.isFinalPage : null;
  if (object(payload) && Object.hasOwn(payload, 'nextCursor') && (payload.nextCursor === '' || (isFinalPage !== null && isFinalPage !== (payload.nextCursor === null)))) result.diagnostics.push(`operator_console.${surface}: $.nextCursor conflicts with $.isFinalPage or is empty`);
  const records = Array.isArray(payload?.[rows]) ? payload[rows].map(reader) : [];
  return { ...result, [rows]: records,
    available: typeof payload?.available === 'boolean' ? payload.available : null,
    complete: typeof payload?.complete === 'boolean' ? payload.complete : null,
    nextCursor, isFinalPage };
}

/** One page only. Follow the opaque nextCursor through the supported API. @param {any} payload */
export function readPackRunsPage(payload) { return readProjectionPage(payload, 'pack-runs', 'runs', readPackRun); }
/** Detail evidence completeness is independent of pagination. @param {any} payload */
export function readPackRunDetail(payload) {
  return { ...readProjectionPage(payload, 'pack-run-detail', 'steps', readPackStep), run: readPackRun(payload?.run ?? null) };
}
/** Failed sources remain diagnostic even when healthy sources have items. @param {any} payload */
export function readAsksPage(payload) { return readProjectionPage(payload, 'asks', 'items', readAsk); }
