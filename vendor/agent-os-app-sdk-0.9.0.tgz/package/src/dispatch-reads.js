/** Interpret the producer-owned dispatch lookup envelope without granting policy authority. */
export function readDispatchLookupResult(value) {
  const unavailable = { available: false, reason: 'dispatch-read-unavailable' };
  if (value?.schema_version !== 1 || value.complete !== true
    || !['found', 'not_found'].includes(value.status)
    || !Array.isArray(value.items) || value.items.length > 1000
    || !Array.isArray(value.roots) || !Array.isArray(value.retry_edges) || value.retry_edges.length > 1000) return unavailable;
  const ids = new Set();
  for (const row of value.items) {
    if (!row || typeof row.launch_request_id !== 'string' || !row.launch_request_id
      || ids.has(row.launch_request_id)) return unavailable;
    ids.add(row.launch_request_id);
  }
  if (value.roots.some(id => !ids.has(id))
    || (value.status === 'not_found' && (ids.size || value.roots.length))
    || (value.status === 'found' && !value.roots.length)
    || value.retry_edges.some(edge => !edge || !ids.has(edge.parent) || !ids.has(edge.child))) return unavailable;
  return { available: true, found: value.status === 'found', items: value.items,
    roots: value.roots, retryEdges: value.retry_edges };
}

/** Keep producer ordering; cycles and terminal ancestors never duplicate the root. */
export function dispatchRetryDescendants(items, edges, launchRequestId) {
  const descendants = new Set([launchRequestId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of edges) {
      if (descendants.has(edge.parent) && !descendants.has(edge.child)) {
        descendants.add(edge.child); changed = true;
      }
    }
  }
  return items.filter(row => row.launch_request_id !== launchRequestId && descendants.has(row.launch_request_id));
}

/** Bounded observation page; partial pages and unknown ownership grant no authority. */
export function readWorkerObservations(value) {
  const unavailable = { available: false, reason: 'worker-observation-unavailable' };
  if (value?.schema_version !== 1 || !['workers', 'sessions', 'provenance'].includes(value.observation)
    || !['found', 'not_found'].includes(value.status) || !Array.isArray(value.items)
    || value.items.length > 100 || typeof value.complete !== 'boolean'
    || value.mutation_authority !== false || value.scope_complete !== false
    || (value.complete ? value.next_offset !== null : !Number.isInteger(value.next_offset) || value.next_offset < 1)
    || (value.status === 'not_found' && value.items.length)) return unavailable;
  const identity = {workers:'run_id', sessions:'session_id', provenance:'launch_request_id'}[value.observation];
  const ids = new Set();
  for (const row of value.items) {
    if (!row || typeof row[identity] !== 'string' || !row[identity] || ids.has(row[identity])) return unavailable;
    ids.add(row[identity]);
  }
  return { available: true, found: value.status === 'found', items: value.items,
    complete: value.complete, nextOffset: value.next_offset, scopeComplete: false, mutationAuthority: false };
}
