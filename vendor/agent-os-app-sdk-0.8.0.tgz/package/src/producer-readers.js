// Offline daemon/CLI readers plus the shared browser projections.
import { bundle, object, diagnosticValue, readLaunchRequestStatus, LAUNCH_REQUEST_STATUSES, TERMINAL_LAUNCH_REQUEST_STATUSES } from './producer-reader-core.js';
export { diagnosticValue, boundedDiagnostics, readLaunchRequestStatus, LAUNCH_REQUEST_STATUSES, TERMINAL_LAUNCH_REQUEST_STATUSES } from './producer-reader-core.js';
export { readPackRunsPage, readPackRunDetail, readPackRun, readPackStep, readAsksPage, readAsk } from './producer-projection-readers.js';

/** @param {Iterable<string>} statuses */
export function assertTerminalLaunchPolicy(statuses) {
  for (const status of statuses) {
    if (!LAUNCH_REQUEST_STATUSES.has(status) || !TERMINAL_LAUNCH_REQUEST_STATUSES.has(status)) {
      throw new Error(`session_ledger: launch_requests.status terminal policy missing from producer vocabulary: ${status}`);
    }
  }
}

/** @param {any} value
 * @param {{identityFields?: string[], allowNonObject?: boolean}} options
 * @returns {{payload: any, rawIdentity: unknown, launchRequestId: string|null, identityDiagnostic: string|null, status: ReturnType<typeof readLaunchRequestStatus>}} */
export function readDispatchReceipt(value, { identityFields = ['launchRequestId', 'dispatchId', 'lrq'], allowNonObject = false } = {}) {
  if (identityFields.length === 0) identityFields = ['launchRequestId', 'dispatchId', 'lrq'];
  const producer = 'cwp_dispatch.dispatch';
  if (typeof value === 'string' && !allowNonObject) {
    if (!value.trim()) throw new Error(`${producer}: $stdout empty`);
    try { value = JSON.parse(value); }
    catch { throw new Error(`${producer}: $stdout invalid JSON`); }
  }
  if (!object(value)) {
    const diagnostic = `${producer}: $stdout invalid type; expected object`;
    if (!allowNonObject) throw new Error(diagnostic);
    return { payload: value, rawIdentity: null, launchRequestId: null, identityDiagnostic: diagnostic, status: readLaunchRequestStatus(null) };
  }
  const selected = identityFields.find(key => typeof value[key] === 'string' ? value[key].trim() : value[key]);
  const rawIdentity = value[selected || identityFields.at(-1)];
  const launchRequestId = typeof rawIdentity === 'string' && rawIdentity.trim() ? rawIdentity : null;
  const identityDiagnostic = launchRequestId ? null : `${producer}: ${(selected ? [selected] : identityFields)
    .map(key => `$.${key} ${Object.hasOwn(value, key) ? 'invalid; expected non-empty string' : 'missing'}`).join('; ')}`;
  const status = readLaunchRequestStatus(value.status);
  if (status.diagnostic) status.diagnostic = `${producer}: $.status ${Object.hasOwn(value, 'status') ? `unrecognized value ${JSON.stringify(value.status)}` : 'missing'}`;
  return { payload: value, rawIdentity, launchRequestId, identityDiagnostic, status };
}

/** Wire booleans take precedence individually, including false.
 * @param {any} payload
 * @returns {{payload: any, status: string|null, terminal: boolean, succeeded: boolean, blockedNeedsDecision: boolean, diagnostics: string[]}} */
export function readDispatchStatus(payload) {
  const value = typeof payload?.status === 'string' ? payload.status.trim().toLowerCase() : payload?.status;
  const status = readLaunchRequestStatus(value);
  const diagnostics = [];
  if (status.diagnostic) diagnostics.push(`cwp_dispatch.dispatch: $.status ${value == null ? 'missing' : `unrecognized value ${JSON.stringify(payload?.status)}`}`);
  for (const key of ['terminal', 'succeeded']) {
    if (payload?.[key] !== undefined && typeof payload[key] !== 'boolean') diagnostics.push(`cwp_dispatch.dispatch: $.${key} missing/invalid boolean`);
  }
  return { payload, status: status.status,
    terminal: typeof payload?.terminal === 'boolean' ? payload.terminal : status.terminal,
    succeeded: typeof payload?.succeeded === 'boolean' ? payload.succeeded : status.succeeded,
    blockedNeedsDecision: status.blockedNeedsDecision, diagnostics };
}

/** @param {any} payload @param {string} provider
 * @returns {{ready: unknown, canServe: unknown, legacyReady: unknown, diagnostics: string[]}} */
export function readBrokerProvider(payload, provider) {
  const producer = 'oauth_broker.server.readyz';
  const path = `provider_states.${provider}`;
  const state = payload?.provider_states?.[provider];
  const legacyReady = payload?.providers?.[provider];
  const diagnostics = [];
  if (!object(payload)) diagnostics.push(`${producer}: $ missing/invalid object`);
  if (!object(state)) diagnostics.push(`${producer}: ${path} missing/invalid object${(Array.isArray(payload?.disabled_providers) && payload.disabled_providers.includes(provider)) ? '; disabled_providers includes provider' : ''}`);
  else {
    for (const key of ['ready', 'can_serve']) {
      if (typeof state[key] !== 'boolean') diagnostics.push(`${producer}: ${path}.${key} missing/invalid boolean`);
      else if (!state[key]) diagnostics.push(`${producer}: ${path}.${key}=false`);
    }
    if (state.state != null && !['ready', 'degraded', 'not_ready'].includes(state.state)) diagnostics.push(`${producer}: ${path}.state unrecognized ${diagnosticValue(state.state)}`);
  }
  if (payload?.providers && Object.hasOwn(payload.providers, provider)) {
    if (typeof legacyReady !== 'boolean') diagnostics.push(`${producer}: providers.${provider} missing/invalid boolean`);
    else if (!legacyReady) diagnostics.push(`${producer}: providers.${provider}=false`);
  }
  return { ready: state?.ready, canServe: state?.can_serve, legacyReady, diagnostics };
}

/** @param {any} payload @param {string[]} [providers]
 * @returns {{payload: any, providers: Record<string, ReturnType<typeof readBrokerProvider>>, diagnostics: string[]}} */
export function readBrokerReadyz(payload, providers = [...new Set([
  ...Object.keys(object(payload?.provider_states) ? payload.provider_states : {}),
  ...Object.keys(object(payload?.providers) ? payload.providers : {}),
  ...(Array.isArray(payload?.disabled_providers) ? payload.disabled_providers.filter(x => typeof x === 'string') : []),
])]) {
  const evidence = Object.fromEntries(providers.map(provider => [provider, readBrokerProvider(payload, provider)]));
  const diagnostics = Object.values(evidence).flatMap(value => value.diagnostics);
  if (!object(payload) && !providers.length) diagnostics.push('oauth_broker.server.readyz: $ missing/invalid object');
  return { payload, providers: evidence, diagnostics };
}

function normalizeWeeklyMeasurement(reading) {
  if (!reading || typeof reading !== 'object') return null;
  const raw = reading.percentRemaining;
  const count = typeof raw === 'number' || (typeof raw === 'string' && raw.trim()) ? Number(raw) : NaN;
  const percentRemaining = Number.isFinite(count) ? count : NaN;
  if (typeof reading.status === 'string') return { ...reading, percentRemaining };
  const measured = reading.confidence === 'measured' && reading.inferred !== true;
  return { status: measured ? 'measured' : (reading.inferred === true ? 'inferred' : String(reading.confidence || 'unknown')), percentRemaining };
}

function weeklyEvidence(floor) {
  const weekly = normalizeWeeklyMeasurement(floor?.weeklyMeasurement);
  if (weekly?.status === 'measured' && Number.isFinite(weekly.percentRemaining)) return { measurement: weekly, source: 'weeklyMeasurement' };
  const fallback = normalizeWeeklyMeasurement(floor?.measurement);
  // PRMSDK-01 explicitly permits measured fallback for null/missing weekly
  // readings, including current producers with a weeklyMeasurementReason.
  if ((floor?.weeklyMeasurement == null && fallback?.status === 'measured')
      || (object(floor) && !Object.hasOwn(floor, 'weeklyMeasurementReason') && fallback)) {
    return { measurement: fallback, source: 'measurement' };
  }
  return { measurement: weekly, source: weekly ? 'weeklyMeasurement' : null };
}

/** @param {any} floor @returns {object|null} */
export function reserveFloorWeeklyMeasurement(floor) { return weeklyEvidence(floor).measurement; }

/** @param {any} floor @param {string} credential
 * @returns {{measurement: any, source: string|null, diagnostics: string[]}} */
export function readReserveFloorWeeklyEvidence(floor, credential) {
  const path = `reserveFloors.${credential}`;
  const prefix = 'quota_reserve.snapshot: ';
  const { measurement, source } = weeklyEvidence(floor);
  const diagnostics = [];
  if (!object(floor)) diagnostics.push(`${prefix}${path} missing/invalid object`);
  else if (!measurement) diagnostics.push(`${prefix}${path}.weeklyMeasurement missing/invalid or null; ${path}.weeklyMeasurementReason=${diagnosticValue(floor.weeklyMeasurementReason)}`);
  else {
    const field = source || 'weeklyMeasurement';
    if (measurement.status !== 'measured') diagnostics.push(`${prefix}${path}.${field}.status=${diagnosticValue(measurement.status)}`);
    if (!Number.isFinite(measurement.percentRemaining) || measurement.percentRemaining < 0 || measurement.percentRemaining > 100) diagnostics.push(`${prefix}${path}.${field}.percentRemaining missing/invalid percentage`);
    else if (measurement.percentRemaining === 0) diagnostics.push(`${prefix}${path}.${field}.percentRemaining=0`);
  }
  return { measurement, source, diagnostics };
}

/** Interpret provider/floor evidence without account thresholds or cap policy.
 * @param {any} payload
 * @returns {{payload: any, providerStatuses: any[], reserveFloors: Record<string, ReturnType<typeof readReserveFloorWeeklyEvidence>>, diagnostics: string[]}} */
export function readFleetQuota(payload) {
  const diagnostics = [];
  if (!object(payload)) diagnostics.push('cwp_dispatch.cli_fleet: $ missing/invalid object');
  if (!Array.isArray(payload?.providerStatuses)) diagnostics.push('cwp_dispatch.cli_fleet: providerStatuses missing/invalid array');
  const providerStatuses = Array.isArray(payload?.providerStatuses) ? payload.providerStatuses : [];
  for (const [index, row] of providerStatuses.entries()) {
    if (!object(row)) { diagnostics.push(`cwp_dispatch.cli_fleet: providerStatuses[${index}] missing/invalid object`); continue; }
    const path = `providerStatuses[provider=${String(row.provider || '').trim().toLowerCase()},authPath=${row.authPath || row.auth_path}]`;
    if (row.cachedEvidenceStale === true) diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.cachedEvidenceStale=true (stale)`);
    if (row.state !== 'ok') diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.state=${diagnosticValue(row.state)}`);
    for (const model of Array.isArray(row.models) ? row.models : []) {
      if (model?.state !== 'ok') diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.models[model=${model?.model}].state=${diagnosticValue(model?.state)}`);
    }
  }
  if (payload?.unavailableSections?.brokerAuth) diagnostics.push(`cwp_dispatch.cli_fleet: unavailableSections.brokerAuth=${diagnosticValue(payload.unavailableSections.brokerAuth)}`);
  if (!object(payload?.reserveFloors)) diagnostics.push('quota_reserve.snapshot: reserveFloors missing/invalid object');
  const reserveFloors = Object.fromEntries(Object.entries(object(payload?.reserveFloors) ? payload.reserveFloors : {}).map(([credential, floor]) => [credential, readReserveFloorWeeklyEvidence(floor, credential)]));
  diagnostics.push(...Object.values(reserveFloors).flatMap(value => value.diagnostics));
  return { payload, providerStatuses, reserveFloors, diagnostics };
}

/** @param {any} payload
 * @returns {{payload: any, accepted: boolean, complete: boolean|null, diagnostics: string[]}} */
export function readAdapterResultEnvelope(payload) {
  const diagnostics = [];
  for (const key of ['ok', 'complete']) {
    if (typeof payload?.[key] !== 'boolean') diagnostics.push(`agent_os_github_adapter.ResultEnvelope: $.${key} missing/invalid boolean`);
    else if (!payload[key]) diagnostics.push(`agent_os_github_adapter.ResultEnvelope: $.${key}=false`);
  }
  return { payload, accepted: payload?.ok === true, complete: typeof payload?.complete === 'boolean' ? payload.complete : null, diagnostics };
}
export const readAdapterReceipt = readAdapterResultEnvelope;

/** @param {any} payload
 * @returns {{accepted: boolean, url: unknown, output: unknown, diagnostics: string[]}} */
export function readPrCreateReceipt(payload) {
  const accepted = payload?.ok === true;
  const diagnostics = [];
  if (!accepted) diagnostics.push(`agent_os_github_adapter.create_pr: $.ok=${JSON.stringify(payload?.ok)}; $.failureClass=${JSON.stringify(payload?.failureClass)}`);
  if (accepted && (typeof payload?.url !== 'string' || !payload.url)) diagnostics.push('agent_os_github_adapter.create_pr: $.url missing/invalid after remote acceptance');
  return { accepted, url: payload?.url || '', output: payload?.output || '', diagnostics };
}

/** Read a named public publication surface without classifying delivery.
 * @param {any} payload @param {string} [surface]
 * @returns {{payload: any, surface: string, diagnostics: string[]}} */
export function readPublicationReceipt(payload, surface = 'pr-open-record') {
  const definition = bundle.producers[surface];
  const producer = `cwp_dispatch.${surface}`;
  const diagnostics = [];
  if (!surface.startsWith('pr-') || !definition) diagnostics.push(`${producer}: $ unrecognized publication surface`);
  else if (!object(payload)) diagnostics.push(`${producer}: $ missing/invalid object`);
  else {
    for (const key of definition.schema.required || []) {
      if (!Object.hasOwn(payload, key)) diagnostics.push(`${producer}: $.${key} missing`);
    }
    for (const [key, schema] of Object.entries(definition.schema.properties || {})) {
      if (!Object.hasOwn(payload, key)) continue;
      const value = payload[key];
      const types = [].concat(schema.type || []);
      const type = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
      if (types.length && !types.includes(type) && !(types.includes('integer') && Number.isInteger(value))) diagnostics.push(`${producer}: $.${key} missing/invalid ${types.join('|')}`);
      else if (schema.enum && !schema.enum.includes(value)) diagnostics.push(`${producer}: $.${key} unrecognized value ${diagnosticValue(value)}`);
    }
  }
  return { payload, surface, diagnostics };
}

/** Compatibility transport shim; interpretation remains in the readers.
 * @param {unknown} stdout @returns {any} */
export function parseDispatchJsonOutput(stdout) {
  const text = String(stdout ?? '').trim();
  if (!text) throw new Error('cwp_dispatch.dispatch: $stdout empty; hq dispatch returned empty stdout');
  try { return JSON.parse(text); } catch {}
  const lines = text.split('\n');
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const candidate = lines.slice(index).join('\n').trim();
    if (!candidate.startsWith('{')) continue;
    try { return JSON.parse(candidate); } catch {}
  }
  throw new Error('cwp_dispatch.dispatch: $stdout invalid JSON; hq dispatch did not return machine-readable JSON');
}

/** @param {unknown} text @param {string} label @returns {any} */
export function parseHqJsonObject(text, label) {
  const raw = String(text || '').trim();
  const invalidJsonMessage = `cwp_dispatch.dispatch: $stdout invalid JSON; ${label} did not return JSON; stdout tail: ${raw.slice(-1000)}`;
  if (!raw) throw new Error(`cwp_dispatch.dispatch: $stdout empty; ${label} produced empty output`);
  try { return JSON.parse(raw); }
  catch {
    const end = raw.lastIndexOf('}');
    // Banner text may contain braces before the actual (possibly multiline) JSON.
    for (let start = raw.indexOf('{'); start >= 0 && start < end; start = raw.indexOf('{', start + 1)) {
      try { return JSON.parse(raw.slice(start, end + 1)); } catch {}
    }
    throw new Error(invalidJsonMessage);
  }
}

/** @param {unknown} stdout @param {{normalize?: boolean}} options @returns {any} */
export function parseHqDispatchStatus(stdout, { normalize = true } = {}) {
  const payload = parseHqJsonObject(stdout, 'hq dispatch status');
  const status = String(payload?.status || '').trim().toLowerCase();
  if (!status) throw new Error('cwp_dispatch.dispatch: $.status missing/invalid; hq dispatch status payload missing status');
  if (!normalize) return { ...payload };
  return { ...payload, status, health: String(payload?.health || '').trim().toLowerCase() || null };
}

/** Caller supplies its existing cap evidence and reserve policy.
 * @param {any} payload
 * @param {{provider: string, authPath: string, cap: any, reserve?: boolean}} options
 * @returns {string[]} */
export function quotaAccountDiagnostics(payload, { provider, authPath, cap, reserve = false }) {
  provider = String(provider || '').trim().toLowerCase();
  const path = `providerStatuses[provider=${provider},authPath=${authPath}]`;
  const row = (Array.isArray(payload?.providerStatuses) ? payload.providerStatuses : []).find(entry => String(entry?.provider || '').trim().toLowerCase() === provider && (entry?.authPath || entry?.auth_path) === authPath);
  const diagnostics = [];
  if (!row) diagnostics.push(`cwp_dispatch.cli_fleet: ${path} missing`);
  else {
    if (row.cachedEvidenceStale === true) diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.cachedEvidenceStale=true (stale)`);
    if (row.state !== 'ok') diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.state=${diagnosticValue(row.state)}`);
    if (!cap.available && cap.modelState && cap.modelState !== 'ok') diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.models[model=${cap.model}].state=${diagnosticValue(cap.modelState)}`);
    if (cap.capped) diagnostics.push(`cwp_dispatch.cli_fleet: ${path}.${cap.capSource === 'model-exhausted' ? 'models' : cap.capSource === 'afh-soft-grounded' ? 'afhGrounding.grounded' : 'state'} ${cap.capSource}`);
  }
  if (payload?.unavailableSections?.brokerAuth) diagnostics.push(`cwp_dispatch.cli_fleet: unavailableSections.brokerAuth=${diagnosticValue(payload.unavailableSections.brokerAuth)}`);
  const credential = `${provider}-${authPath}`;
  const floor = payload?.reserveFloors?.[credential];
  diagnostics.push(...readReserveFloorWeeklyEvidence(floor, credential).diagnostics);
  if (reserve) for (const key of ['active', 'paused', 'nearCap']) {
    if (floor?.[key] !== false) diagnostics.push(`quota_reserve.snapshot: reserveFloors.${credential}.${key}=${diagnosticValue(floor?.[key])}; expected false`);
  }
  return diagnostics;
}
