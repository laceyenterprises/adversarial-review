// The entire Node App SDK — the client half of the OS↔App Contract.
//
// connect()/connectSync() return a session whose surface (dispatch,
// dispatchStatus, workflowAction, on, systemState) is identical in three modes:
// 'agent-os' (HTTP to the app-contract-endpoint on loopback), 'standalone'
// (in-process adapters / CLI shell-out), and 'hybrid' (ARC-23: route to
// agent-os while healthy, fail over to standalone on the ARC-07 probe/hard-error
// contract, and resume with hysteresis). agent-os on() is now a real SSE client
// backed by GET /v1/topics/sse. Hybrid routing and SSE are purely client-side
// behavior; they do NOT touch the wire contract (CONTRACT_VERSION stays '1.0')
// or the action-id derivation, so they fall outside the parity invariant below —
// but the two files are still kept structurally mirrored on purpose.
//
// PARITY INVARIANT: this file is hand-mirrored by
// python/src/agent_os_app_sdk/__init__.py. Any change to
// deriveWorkflowActionId, canonical JSON serialization (ensureAsciiJsonString
// vs Python's ensure_ascii=True), the app_id regex, the strip-app_id
// behavior, or bootstrap-token resolution must land in BOTH files in the same
// change, or action ids diverge across languages and break the server's
// idempotency keys. Architecture: platform/app-sdk/app-sdk-walkthrough.md.

import { readFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { isAbsolute, relative, resolve } from 'node:path';

const CONTRACT_VERSION = '1.0';
const DEFAULT_ENDPOINT_URL = 'http://127.0.0.1:8003';
const DEFAULT_REQUEST_TIMEOUT_MS = 10_000;
const APP_ID_RE = /^[a-z0-9][a-z0-9._-]*$/;
const WORKFLOW_ACTION_OPERATIONS = new Set([
  'workflow.run.create',
  'workflow.trigger.fire',
  'workflow.run.replay',
  'workflow.run.cancel',
  'dispatch.cancel',
]);
const LAUNCH_INTENT_OPERATIONS = new Set(['workflow.run.create', 'workflow.trigger.fire']);

// Hybrid-mode defaults mirror the ARC-07 health-router contract: fail over from
// os→local on k=3 consecutive probe failures (or one hard contract error), and
// resume local→os only after m=6 healthy probes spanning at least a 5-minute
// hysteresis window. Every threshold is injectable via connect({ hybrid: {...} }).
const DEFAULT_HYBRID = {
  failoverProbeFailures: 3,
  resumeHealthyProbes: 6,
  resumeHealthyWindowMs: 5 * 60 * 1000,
  dispatchLatencyBudgetMs: 2_000,
  reconnectDelayMs: 1_000,
};

export async function connect(options = {}) {
  const config = normalizeConnectOptions(options);
  if (config.mode === 'hybrid') {
    return connectHybrid(config);
  }
  if (config.mode === 'agent-os') {
    return connectAgentOs(config);
  }
  return new StandaloneSession(config);
}

function normalizeConnectOptions(options) {
  const rawAppId = options.app_id ?? options.appId;
  if (!rawAppId) {
    throw new Error('connect requires app_id');
  }
  const appId = String(rawAppId);
  validateAppId(appId);
  const mode = options.mode ?? 'agent-os';
  if (mode !== 'agent-os' && mode !== 'standalone' && mode !== 'hybrid') {
    throw new Error("mode must be 'agent-os', 'standalone', or 'hybrid'");
  }
  return {
    ...options,
    app_id: appId,
    app_version: options.app_version ?? options.appVersion ?? null,
    mode,
    subscribes: options.subscribes ?? [],
    endpoint_url: trimTrailingSlash(options.endpoint_url ?? options.endpointUrl ?? process.env.APP_CONTRACT_ENDPOINT_URL ?? DEFAULT_ENDPOINT_URL),
    request_timeout_ms: options.request_timeout_ms ?? options.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS,
    hybrid: normalizeHybridOptions(options.hybrid ?? options.hybridOptions),
    sse_reconnect_delay_ms: options.sse_reconnect_delay_ms ?? options.sseReconnectDelayMs,
  };
}

function normalizeHybridOptions(raw = {}) {
  return {
    failoverProbeFailures: raw.failoverProbeFailures ?? raw.k ?? DEFAULT_HYBRID.failoverProbeFailures,
    resumeHealthyProbes: raw.resumeHealthyProbes ?? raw.m ?? DEFAULT_HYBRID.resumeHealthyProbes,
    resumeHealthyWindowMs: raw.resumeHealthyWindowMs ?? DEFAULT_HYBRID.resumeHealthyWindowMs,
    dispatchLatencyBudgetMs: raw.dispatchLatencyBudgetMs ?? DEFAULT_HYBRID.dispatchLatencyBudgetMs,
    reconnectDelayMs: raw.reconnectDelayMs,
    now: typeof raw.now === 'function' ? raw.now : null,
    onTransition: typeof raw.onTransition === 'function' ? raw.onTransition : null,
    logger: typeof raw.logger === 'function' ? raw.logger : null,
  };
}

async function connectAgentOs(config) {
  const bootstrapToken = await resolveBootstrapToken(config);
  const body = {
    op: 'register',
    contract_version: CONTRACT_VERSION,
    app_id: config.app_id,
    app_version: config.app_version,
    mode: 'agent-os',
    subscribes: config.subscribes,
  };
  const response = await requestJson(`${config.endpoint_url}/v1/register`, {
    method: 'POST',
    token: bootstrapToken,
    body,
    timeoutMs: config.request_timeout_ms,
  });
  if (!response.session_token) {
    throw new Error('register response did not include session_token');
  }
  return new AgentOsSession(config, response.session_token);
}

async function resolveBootstrapToken(config) {
  if (config.bootstrap_token ?? config.bootstrapToken) {
    return config.bootstrap_token ?? config.bootstrapToken;
  }
  const tokenFile = config.bootstrap_token_path ?? config.bootstrapTokenPath ?? process.env.APP_CONTRACT_BOOTSTRAP_TOKEN_FILE;
  if (tokenFile) {
    return (await readFile(tokenFile, 'utf8')).trim();
  }
  if (process.env.APP_CONTRACT_BOOTSTRAP_TOKEN) {
    return process.env.APP_CONTRACT_BOOTSTRAP_TOKEN;
  }
  const hqRoot = config.hq_root ?? config.hqRoot ?? process.env.APP_CONTRACT_HQ_ROOT ?? process.env.HQ_ROOT;
  if (hqRoot) {
    const bootstrapDir = resolve(String(hqRoot), 'apps', 'bootstrap');
    const tokenPath = resolve(bootstrapDir, `${config.app_id}.bearer`);
    if (!pathInside(tokenPath, bootstrapDir)) {
      throw new Error('bootstrap token path escaped apps/bootstrap');
    }
    return (await readFile(tokenPath, 'utf8')).trim();
  }
  throw new Error('agent-os mode requires a bootstrap token or bootstrap token file');
}

class AgentOsSession {
  constructor(config, sessionToken) {
    this.app_id = config.app_id;
    this.mode = 'agent-os';
    this.endpoint_url = config.endpoint_url;
    this.sessionToken = sessionToken;
    this.requestTimeoutMs = config.request_timeout_ms;
    this.handlers = new Map();
    this._sse = null;
    this._sseReconnectDelayMs = config.sse_reconnect_delay_ms ?? DEFAULT_HYBRID.reconnectDelayMs;
    this.workflow = workflowActionNamespace((operation, payload) => this.workflowAction(operation, payload));
  }

  async dispatch(payload) {
    const body = stripUndefined({ ...payload });
    delete body.app_id;
    return requestJson(`${this.endpoint_url}/v1/dispatch`, {
      method: 'POST',
      token: this.sessionToken,
      body,
      timeoutMs: this.requestTimeoutMs,
    });
  }

  async dispatchStatus(requestId) {
    return requestJson(`${this.endpoint_url}/v1/dispatch_status`, {
      method: 'POST',
      token: this.sessionToken,
      body: { request_id: requestId },
      timeoutMs: this.requestTimeoutMs,
    });
  }

  async workflowAction(operation, payload = {}) {
    validateWorkflowActionOperation(operation);
    const body = stripUndefined({ ...payload, operation });
    delete body.app_id;
    return requestJson(`${this.endpoint_url}/v1/workflow_action`, {
      method: 'POST',
      token: this.sessionToken,
      body,
      timeoutMs: this.requestTimeoutMs,
    });
  }

  // Real SSE-backed subscription (ARC-23). The first on() opens one streaming
  // GET /v1/topics/sse; every subscribed pattern is filtered client-side, so a
  // new handler never forces a reconnect. Handlers receive the endpoint frame
  // { topic, payload, published_at }. Unsubscribing the last handler tears the
  // stream down. The registration's `subscribes` list is the server-side
  // authorization boundary; patterns here only narrow what the app observes.
  on(topic, cb) {
    if (!this.handlers.has(topic)) {
      this.handlers.set(topic, new Set());
    }
    this.handlers.get(topic).add(cb);
    this._ensureSse();
    return () => {
      const handlers = this.handlers.get(topic);
      if (handlers) {
        handlers.delete(cb);
        if (handlers.size === 0) {
          this.handlers.delete(topic);
        }
      }
      if (this.handlers.size === 0) {
        this._closeSse();
      }
    };
  }

  _ensureSse() {
    if (this._sse) {
      return;
    }
    this._sse = new SseStream({
      url: `${this.endpoint_url}/v1/topics/sse`,
      token: this.sessionToken,
      reconnectDelayMs: this._sseReconnectDelayMs,
      onTopic: (topic, payload, publishedAt) => this._emit(topic, { topic, payload, published_at: publishedAt }),
    });
    this._sse.start();
  }

  _closeSse() {
    if (this._sse) {
      this._sse.close();
      this._sse = null;
    }
  }

  // SSE liveness for the hybrid probe: true (live), false (open but not ready),
  // or null (no subscription open, so liveness is not a failure signal).
  sseLive() {
    return this._sse ? this._sse.isLive() : null;
  }

  close() {
    this._closeSse();
  }

  async systemState(kind) {
    return { kind, mode: this.mode, unavailable: true };
  }

  _emit(topic, event) {
    const frame = canonicalTopicFrame(topic, event);
    for (const [pattern, handlers] of this.handlers.entries()) {
      if (topicMatches(pattern, topic)) {
        for (const handler of handlers) {
          handler(frame);
        }
      }
    }
  }
}

class StandaloneSession {
  constructor(config) {
    this.app_id = config.app_id;
    this.mode = 'standalone';
    this.config = config;
    this.handlers = new Map();
    this.dispatches = new Map();
    this.workflowActions = new Map();
    this.workflow = workflowActionNamespace((operation, payload) => this.workflowAction(operation, payload));
  }

  async dispatch(payload) {
    const requestId = requireRequestId(payload);
    const existing = this.dispatches.get(requestId);
    if (existing) {
      return existing;
    }
    const pending = this._acceptDispatch(payload, requestId);
    this.dispatches.set(requestId, pending);
    try {
      const accepted = await pending;
      this.dispatches.set(requestId, accepted);
      return accepted;
    } catch (error) {
      if (this.dispatches.get(requestId) === pending) {
        this.dispatches.delete(requestId);
      }
      throw error;
    }
  }

  async _acceptDispatch(payload, requestId) {
    const launchRequestId = await this._launch(payload);
    const accepted = {
      app_id: this.app_id,
      request_id: requestId,
      launch_request_id: launchRequestId,
      watch_url: `standalone://watch/${launchRequestId}`,
      audit_ref: `standalone://audit/${this.app_id}/${requestId}`,
    };
    this.dispatches.set(requestId, accepted);
    this._emit(`health.worker.terminal.${launchRequestId}`, {
      status: 'accepted',
      launch_request_id: launchRequestId,
      request_id: requestId,
    });
    return accepted;
  }

  async _launch(payload) {
    if (typeof this.config.standalone_dispatcher === 'function') {
      const result = await this.config.standalone_dispatcher(payload);
      return normalizeLaunchRequestId(result);
    }
    const command = this.config.dispatch_command ?? this.config.dispatchCommand;
    if (command) {
      const result = await runDispatchCommand(command, payload);
      return normalizeLaunchRequestId(result);
    }
    return `standalone-${randomUUID()}`;
  }

  async dispatchStatus(requestId) {
    const existing = await this.dispatches.get(requestId);
    if (!existing) {
      return { status: 'not_found', app_id: this.app_id, request_id: requestId };
    }
    return { status: 'found', ...existing };
  }

  async workflowAction(operation, payload = {}) {
    validateWorkflowActionOperation(operation);
    const normalized = normalizeWorkflowActionPayload(this.app_id, operation, payload);
    const existing = this.workflowActions.get(normalized.action_id);
    if (existing) {
      return existing;
    }
    const pending = this._acceptWorkflowAction(normalized);
    this.workflowActions.set(normalized.action_id, pending);
    try {
      const accepted = await pending;
      this.workflowActions.set(normalized.action_id, accepted);
      return accepted;
    } catch (error) {
      if (this.workflowActions.get(normalized.action_id) === pending) {
        this.workflowActions.delete(normalized.action_id);
      }
      throw error;
    }
  }

  async _acceptWorkflowAction(normalized) {
    const adapter = this.config.standalone_workflow_action_handler ?? this.config.standaloneWorkflowActionHandler;
    let result;
    if (typeof adapter === 'function') {
      result = await adapter(normalized);
    } else {
      result = {
        manual_reconciliation: true,
        audit_ref: `standalone://audit/workflow-action/${this.app_id}/${normalized.action_id}`,
        detail: 'standalone workflow action adapter is not configured',
      };
    }
    if (result?.manual_reconciliation || result?.state === 'manual-reconciliation') {
      return workflowActionResponse(normalized, {
        state: 'manual-reconciliation',
        manual_reconciliation: {
          audit_ref: result.audit_ref ?? `standalone://audit/workflow-action/${this.app_id}/${normalized.action_id}`,
          detail: result.detail ?? 'standalone workflow action could not persist the action id',
        },
      });
    }
    return workflowActionResponse(normalized, {
      state: 'result',
      result: {
        ...result,
        action_id: normalized.action_id,
        audit_ref: result?.audit_ref ?? `standalone://audit/workflow-action/${this.app_id}/${normalized.action_id}`,
      },
    });
  }

  on(topic, cb) {
    if (!this.handlers.has(topic)) {
      this.handlers.set(topic, new Set());
    }
    this.handlers.get(topic).add(cb);
    return () => this.handlers.get(topic)?.delete(cb);
  }

  async systemState(kind) {
    return { kind, mode: this.mode, unavailable: true };
  }

  close() {
    // Standalone holds no network resources; provided for surface parity with
    // AgentOsSession/HybridSession so app code can call close() in any mode.
  }

  _emit(topic, event) {
    const frame = canonicalTopicFrame(topic, event);
    for (const [pattern, handlers] of this.handlers.entries()) {
      if (topicMatches(pattern, topic)) {
        for (const handler of handlers) {
          handler(frame);
        }
      }
    }
  }
}

// A minimal Server-Sent Events reader for GET /v1/topics/sse. It parses the
// endpoint's `event: ready` handshake and `event: topic` frames, tolerates
// keepalive comment lines, and auto-reconnects with a bounded delay unless
// reconnectDelayMs is null. All errors are swallowed (telemetry is best-effort);
// liveness is exposed via isLive() for the hybrid probe.
class SseStream {
  constructor({ url, token, onTopic, onReady = null, onError = null, reconnectDelayMs = DEFAULT_HYBRID.reconnectDelayMs, fetchImpl = fetch }) {
    this.url = url;
    this.token = token;
    this.onTopic = onTopic;
    this.onReady = onReady;
    this.onError = onError;
    this.reconnectDelayMs = reconnectDelayMs;
    this._fetch = fetchImpl;
    this._closed = false;
    this._ready = false;
    this._controller = null;
    this._reconnectTimer = null;
    this._buffer = '';
  }

  start() {
    if (this._closed) {
      return;
    }
    this._connect();
  }

  isLive() {
    return this._ready && !this._closed;
  }

  async _connect() {
    if (this._closed) {
      return;
    }
    this._ready = false;
    this._buffer = '';
    const controller = new AbortController();
    this._controller = controller;
    let response;
    try {
      response = await this._fetch(this.url, {
        method: 'GET',
        headers: { Authorization: `Bearer ${this.token}`, Accept: 'text/event-stream' },
        signal: controller.signal,
      });
    } catch (error) {
      if (this._closed || error?.name === 'AbortError') {
        return;
      }
      this._scheduleReconnect(error);
      return;
    }
    if (!response.ok || !response.body) {
      this._reportError(new Error(`app-contract sse ${response.status}`));
      this._scheduleReconnect();
      return;
    }
    try {
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) {
          break;
        }
        this._feed(decoder.decode(value, { stream: true }));
      }
    } catch (error) {
      if (this._closed || error?.name === 'AbortError') {
        return;
      }
      this._reportError(error);
    }
    if (!this._closed) {
      this._scheduleReconnect();
    }
  }

  _scheduleReconnect(error) {
    this._ready = false;
    if (this._closed || this.reconnectDelayMs === null || this.reconnectDelayMs === undefined) {
      return;
    }
    if (error) {
      this._reportError(error);
    }
    this._reconnectTimer = setTimeout(() => {
      this._reconnectTimer = null;
      this._connect();
    }, this.reconnectDelayMs);
    if (typeof this._reconnectTimer.unref === 'function') {
      this._reconnectTimer.unref();
    }
  }

  _reportError(error) {
    if (this.onError) {
      try {
        this.onError(error);
      } catch {
        // an error handler that throws must not wedge the reader
      }
    }
  }

  _feed(chunk) {
    this._buffer += chunk.replace(/\r\n/g, '\n');
    let index;
    while ((index = this._buffer.indexOf('\n\n')) >= 0) {
      const raw = this._buffer.slice(0, index);
      this._buffer = this._buffer.slice(index + 2);
      this._handleEvent(raw);
    }
  }

  _handleEvent(raw) {
    let event = 'message';
    const dataLines = [];
    for (const line of raw.split('\n')) {
      if (!line || line.startsWith(':')) {
        continue;
      }
      const colon = line.indexOf(':');
      const field = colon === -1 ? line : line.slice(0, colon);
      let value = colon === -1 ? '' : line.slice(colon + 1);
      if (value.startsWith(' ')) {
        value = value.slice(1);
      }
      if (field === 'event') {
        event = value;
      } else if (field === 'data') {
        dataLines.push(value);
      }
    }
    if (event === 'ready') {
      this._ready = true;
      if (this.onReady) {
        this.onReady();
      }
      return;
    }
    if (event === 'topic' && dataLines.length) {
      let frame;
      try {
        frame = JSON.parse(dataLines.join('\n'));
      } catch {
        return;
      }
      this._ready = true;
      if (this.onTopic) {
        this.onTopic(frame.topic, frame.payload, frame.published_at);
      }
    }
  }

  close() {
    this._closed = true;
    this._ready = false;
    if (this._reconnectTimer) {
      clearTimeout(this._reconnectTimer);
      this._reconnectTimer = null;
    }
    if (this._controller) {
      try {
        this._controller.abort();
      } catch {
        // abort races with a completed stream; nothing to do
      }
      this._controller = null;
    }
  }
}

// The hybrid health-router state machine (ARC-07 contract). Pure and clock-free:
// callers feed it probe results and hard errors with explicit timestamps, and it
// returns a transition object (or null). Thresholds are injectable so consumers
// can tighten/loosen failover and resume behavior.
export class HealthRouter {
  constructor(options = {}) {
    this.failoverProbeFailures = options.failoverProbeFailures ?? DEFAULT_HYBRID.failoverProbeFailures;
    this.resumeHealthyProbes = options.resumeHealthyProbes ?? DEFAULT_HYBRID.resumeHealthyProbes;
    this.resumeHealthyWindowMs = options.resumeHealthyWindowMs ?? DEFAULT_HYBRID.resumeHealthyWindowMs;
    this._now = typeof options.now === 'function' ? options.now : () => Date.now();
    this.mode = options.initialMode === 'local' ? 'local' : 'os';
    this._consecutiveFailures = 0;
    this._healthyProbes = 0;
    this._firstHealthyAt = null;
    this._probeCount = 0;
    this.lastFailoverAt = null;
    this.lastResumeAt = null;
    this.lastTransition = null;
  }

  recordProbe(healthy, at = this._now()) {
    this._probeCount += 1;
    if (this.mode === 'os') {
      if (healthy) {
        this._consecutiveFailures = 0;
        return null;
      }
      this._consecutiveFailures += 1;
      if (this._consecutiveFailures >= this.failoverProbeFailures) {
        return this._failover('probe-failures', at);
      }
      return null;
    }
    if (!healthy) {
      this._healthyProbes = 0;
      this._firstHealthyAt = null;
      return null;
    }
    this._healthyProbes += 1;
    if (this._firstHealthyAt === null) {
      this._firstHealthyAt = at;
    }
    const windowElapsed = at - this._firstHealthyAt;
    if (this._healthyProbes >= this.resumeHealthyProbes && windowElapsed >= this.resumeHealthyWindowMs) {
      return this._resume(at);
    }
    return null;
  }

  // One hard contract error fails over immediately from os, bypassing the k
  // consecutive-failure count. A no-op when already local.
  recordHardError(at = this._now()) {
    if (this.mode !== 'os') {
      return null;
    }
    return this._failover('hard-error', at);
  }

  // Deterministically force local (e.g. os registration failed at connect).
  forceLocal(reason = 'forced', at = this._now()) {
    if (this.mode !== 'os') {
      return null;
    }
    return this._failover(reason, at);
  }

  _failover(reason, at) {
    this.mode = 'local';
    this._consecutiveFailures = 0;
    this._healthyProbes = 0;
    this._firstHealthyAt = null;
    this.lastFailoverAt = at;
    this.lastTransition = { from: 'os', to: 'local', reason, at };
    return this.lastTransition;
  }

  _resume(at) {
    this.mode = 'os';
    this._consecutiveFailures = 0;
    this._healthyProbes = 0;
    this._firstHealthyAt = null;
    this.lastResumeAt = at;
    this.lastTransition = { from: 'local', to: 'os', reason: 'healthy-probes', at };
    return this.lastTransition;
  }

  status() {
    return {
      mode: this.mode,
      consecutive_failures: this._consecutiveFailures,
      healthy_probe_streak: this._healthyProbes,
      first_healthy_at: this._firstHealthyAt,
      probe_count: this._probeCount,
      last_failover_at: this.lastFailoverAt,
      last_resume_at: this.lastResumeAt,
      last_transition: this.lastTransition,
      thresholds: {
        failover_probe_failures: this.failoverProbeFailures,
        resume_healthy_probes: this.resumeHealthyProbes,
        resume_healthy_window_ms: this.resumeHealthyWindowMs,
      },
    };
  }
}

async function connectHybrid(config) {
  const session = new HybridSession(config);
  await session._init();
  return session;
}

// HybridSession generalizes adversarial-review's lifeline pattern: one surface
// that routes to the os endpoint when healthy and to an in-process standalone
// session when not. Runs finish in the mode they started (a request_id is pinned
// on first sight), failover only redirects *new* runs, and callers can reconcile
// explicitly identified active os requests without re-issuing them.
class HybridSession {
  constructor(config) {
    this.app_id = config.app_id;
    this.mode = 'hybrid';
    this.config = config;
    this.endpoint_url = config.endpoint_url;
    this.requestTimeoutMs = config.request_timeout_ms;
    this._hybrid = config.hybrid;
    this._router = new HealthRouter({
      failoverProbeFailures: this._hybrid.failoverProbeFailures,
      resumeHealthyProbes: this._hybrid.resumeHealthyProbes,
      resumeHealthyWindowMs: this._hybrid.resumeHealthyWindowMs,
      now: this._hybrid.now,
    });
    this._standalone = new StandaloneSession({ ...config, mode: 'standalone' });
    this._agentOs = null;
    this._agentOsPromise = null;
    this._requestModes = new Map();
    this._latencies = [];
    this._maxLatencySamples = 64;
    this._subscriptions = [];
    this.handlers = new Map();
    this.workflow = workflowActionNamespace((operation, payload) => this.workflowAction(operation, payload));
  }

  async _init() {
    try {
      await this._ensureAgentOs();
    } catch (error) {
      // os unreachable at connect: start in local fallback, resume later.
      this._applyTransition(this._router.forceLocal('connect-failed'));
      this._log('warn', `hybrid connect could not reach os endpoint; starting in local mode: ${error?.message ?? error}`);
    }
  }

  async _ensureAgentOs() {
    if (this._agentOs) {
      return this._agentOs;
    }
    if (!this._agentOsPromise) {
      this._agentOsPromise = connectAgentOs(this.config)
        .then((session) => {
          this._agentOs = session;
          return session;
        })
        .finally(() => {
          this._agentOsPromise = null;
        });
    }
    return this._agentOsPromise;
  }

  _now() {
    return this._hybrid.now ? this._hybrid.now() : Date.now();
  }

  async dispatch(payload) {
    const requestId = requireRequestId(payload);
    const hadPin = this._requestModes.has(requestId);
    const mode = hadPin ? this._requestModes.get(requestId) : this._router.mode;
    if (!hadPin) {
      this._requestModes.set(requestId, mode);
    }
    if (mode !== 'os') {
      try {
        return await this._standalone.dispatch(payload);
      } catch (error) {
        if (!hadPin) {
          this._requestModes.delete(requestId);
        }
        throw error;
      }
    }
    const started = this._now();
    let session;
    try {
      session = await this._ensureAgentOs();
    } catch (error) {
      if (!hadPin) {
        this._requestModes.delete(requestId);
      }
      this._applyTransition(this._router.recordHardError());
      throw error;
    }
    try {
      const accepted = await session.dispatch(payload);
      this._recordLatency(this._now() - started);
      return accepted;
    } catch (error) {
      if (!hadPin) {
        this._requestModes.delete(requestId);
      }
      if (isHardContractError(error)) {
        this._applyTransition(this._router.recordHardError());
      }
      throw error;
    }
  }

  async dispatchStatus(requestId) {
    const mode = this._requestModes.get(requestId) ?? this._router.mode;
    if (mode !== 'os') {
      return this._standalone.dispatchStatus(requestId);
    }
    const session = await this._ensureAgentOs();
    return session.dispatchStatus(requestId);
  }

  async workflowAction(operation, payload = {}) {
    const requestId = workflowActionRequestId(operation, payload);
    const launchIntent = LAUNCH_INTENT_OPERATIONS.has(operation);
    const hadPin = requestId ? this._requestModes.has(requestId) : false;
    const mode = requestId ? (hadPin ? this._requestModes.get(requestId) : this._router.mode) : this._router.mode;
    const rollbackNewLaunchPin = () => {
      if (requestId && launchIntent && !hadPin) {
        this._requestModes.delete(requestId);
      }
    };
    if (requestId && launchIntent && !hadPin) {
      this._requestModes.set(requestId, mode);
    }
    if (mode !== 'os') {
      try {
        return await this._standalone.workflowAction(operation, payload);
      } catch (error) {
        rollbackNewLaunchPin();
        throw error;
      }
    }
    let session;
    try {
      session = await this._ensureAgentOs();
    } catch (error) {
      rollbackNewLaunchPin();
      this._applyTransition(this._router.recordHardError());
      throw error;
    }
    try {
      return await session.workflowAction(operation, payload);
    } catch (error) {
      rollbackNewLaunchPin();
      if (isHardContractError(error)) {
        this._applyTransition(this._router.recordHardError());
      }
      throw error;
    }
  }

  // Probe the os endpoint and feed the router. Healthy iff healthz is ok, the
  // observed dispatch p95 is under budget (or no samples yet), and any open SSE
  // stream is live. Returns a structured probe result and applies any transition.
  async probe(at = this._now()) {
    const healthzOk = await this._healthz();
    const p95 = this._latencyP95();
    const latencyOk = p95 === null || p95 <= this._hybrid.dispatchLatencyBudgetMs;
    const sseLive = this._agentOs ? this._agentOs.sseLive() : null;
    const healthy = healthzOk && latencyOk && sseLive !== false;
    const transition = this._router.recordProbe(healthy, at);
    await this._applyTransitionAsync(transition);
    return {
      healthy,
      healthz_ok: healthzOk,
      dispatch_p95_ms: p95,
      sse_live: sseLive,
      mode: this._router.mode,
    };
  }

  async _healthz() {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.requestTimeoutMs);
      try {
        const response = await fetch(`${this.endpoint_url}/healthz`, { method: 'GET', signal: controller.signal });
        if (!response.ok) {
          return false;
        }
        const text = await response.text();
        const data = text ? JSON.parse(text) : {};
        return data.ok === true;
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return false;
    }
  }

  // Adopt (never re-issue) explicitly identified active os dispatches.
  async reconcile(requestIds = []) {
    const ids = requestIds;
    if (ids.length === 0) {
      return [];
    }
    let session;
    try {
      session = await this._ensureAgentOs();
    } catch {
      return [];
    }
    const results = [];
    for (const requestId of ids) {
      try {
        const status = await session.dispatchStatus(requestId);
        this._requestModes.set(requestId, 'os');
        results.push({ request_id: requestId, status });
      } catch (error) {
        results.push({ request_id: requestId, error: error?.message ?? String(error) });
      }
    }
    return results;
  }

  forget(requestId) {
    return this._requestModes.delete(requestId);
  }

  on(topic, cb) {
    const subscription = { topic, cb, osUnsub: null };
    const handlers = this.handlers.get(topic) ?? [];
    handlers.push(cb);
    this.handlers.set(topic, handlers);
    subscription.standaloneUnsub = this._standalone.on(topic, cb);
    this._subscriptions.push(subscription);
    if (this._router.mode === 'os' && this._agentOs) {
      subscription.osUnsub = this._agentOs.on(topic, cb);
    }
    return () => {
      subscription.standaloneUnsub?.();
      subscription.osUnsub?.();
      const index = this._subscriptions.indexOf(subscription);
      if (index >= 0) {
        this._subscriptions.splice(index, 1);
      }
      const localHandlers = this.handlers.get(topic) ?? [];
      const handlerIndex = localHandlers.indexOf(cb);
      if (handlerIndex >= 0) {
        localHandlers.splice(handlerIndex, 1);
      }
      if (localHandlers.length === 0) {
        this.handlers.delete(topic);
      }
    };
  }

  async systemState(kind) {
    if (this._router.mode === 'os' && this._agentOs) {
      return this._agentOs.systemState(kind);
    }
    return this._standalone.systemState(kind);
  }

  runtimeStatus() {
    const runs = { os: 0, local: 0 };
    for (const mode of this._requestModes.values()) {
      runs[mode] = (runs[mode] ?? 0) + 1;
    }
    return {
      mode: this._router.mode,
      ...this._router.status(),
      dispatch_p95_ms: this._latencyP95(),
      runs,
    };
  }

  close() {
    this._agentOs?.close();
    this._standalone.close();
  }

  _recordLatency(ms) {
    this._latencies.push(ms);
    if (this._latencies.length > this._maxLatencySamples) {
      this._latencies.shift();
    }
  }

  _latencyP95() {
    if (this._latencies.length === 0) {
      return null;
    }
    const sorted = [...this._latencies].sort((a, b) => a - b);
    const rank = Math.ceil(sorted.length * 0.95) - 1;
    return sorted[Math.min(Math.max(rank, 0), sorted.length - 1)];
  }

  _applyTransition(transition) {
    if (!transition) {
      return;
    }
    if (transition.to === 'os') {
      this._wireOsSubscriptions();
    } else {
      this._unwireOsSubscriptions();
    }
    this._log('info', `hybrid runtime ${transition.from} -> ${transition.to} (${transition.reason})`);
    this._hybrid.onTransition?.(transition);
    this._emit('runtime.transition', { topic: 'runtime.transition', payload: transition });
  }

  async _applyTransitionAsync(transition) {
    this._applyTransition(transition);
    if (transition && transition.to === 'os') {
      // Resume follow-up: the os session may have been unregistered while local,
      // so bring it up and (re)wire subscriptions now that it exists.
      try {
        await this._ensureAgentOs();
        this._wireOsSubscriptions();
      } catch (error) {
        this._log('warn', `hybrid resume follow-up failed: ${error?.message ?? error}`);
        this._applyTransition(this._router.recordHardError());
      }
    }
  }

  _wireOsSubscriptions() {
    if (!this._agentOs) {
      return;
    }
    for (const subscription of this._subscriptions) {
      if (!subscription.osUnsub) {
        subscription.osUnsub = this._agentOs.on(subscription.topic, subscription.cb);
      }
    }
  }

  _unwireOsSubscriptions() {
    for (const subscription of this._subscriptions) {
      if (subscription.osUnsub) {
        subscription.osUnsub();
        subscription.osUnsub = null;
      }
    }
    this._agentOs?.close();
  }

  _log(level, message) {
    if (this._hybrid.logger) {
      this._hybrid.logger(level, message);
    }
  }

  _emit(topic, event) {
    for (const [pattern, handlers] of this.handlers.entries()) {
      if (topicMatches(pattern, topic)) {
        for (const handler of handlers) {
          handler(event);
        }
      }
    }
  }
}

// A hard contract error is a transport failure or an app-contract error the
// endpoint could not service (5xx-class or unparseable response). These fail the
// hybrid router over immediately; ordinary 4xx validation errors do not.
function isHardContractError(error) {
  const message = String(error?.message ?? error ?? '');
  if (message.startsWith('app-contract network error') || message.startsWith('app-contract transport error')) {
    return true;
  }
  if (message.includes('app-contract bad_response')) {
    return true;
  }
  if (message.includes('timed out')) {
    return true;
  }
  const match = message.match(/^app-contract (\d{3})\b/);
  if (match) {
    return Number(match[1]) >= 500;
  }
  // Non-contract-shaped errors (ECONNREFUSED, DNS, socket resets) are hard.
  return !message.startsWith('app-contract');
}

function workflowActionRequestId(operation, payload) {
  if (LAUNCH_INTENT_OPERATIONS.has(operation)) {
    return payload?.request_id ? String(payload.request_id) : null;
  }
  const keys = operation === 'dispatch.cancel'
    ? ['dispatch_id', 'launch_request_id', 'target_run_or_step']
    : ['target_run_or_step', 'target_run_id', 'target_step_id', 'run_id', 'step_id', 'dispatch_id'];
  for (const key of keys) {
    if (payload?.[key]) {
      return String(payload[key]);
    }
  }
  return null;
}

function canonicalTopicFrame(topic, payload, publishedAt = new Date().toISOString()) {
  if (
    payload
    && typeof payload === 'object'
    && payload.topic === topic
    && Object.prototype.hasOwnProperty.call(payload, 'payload')
    && Object.prototype.hasOwnProperty.call(payload, 'published_at')
  ) {
    return payload;
  }
  return { topic, payload, published_at: publishedAt };
}

async function requestJson(url, { method, token, body, timeoutMs = DEFAULT_REQUEST_TIMEOUT_MS }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(stripUndefined(body)),
      signal: controller.signal,
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(`app-contract request timed out after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
  const text = await response.text();
  const data = parseJsonResponse(text, response.status);
  if (!response.ok) {
    const code = data?.error?.code ?? response.status;
    const message = data?.error?.message ?? response.statusText;
    throw new Error(`app-contract ${code}: ${message}`);
  }
  return data;
}

function parseJsonResponse(text, status) {
  if (!text) {
    return {};
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    const snippet = text.slice(0, 120);
    throw new Error(`app-contract bad_response: non-JSON response (status ${status}): ${snippet}`);
  }
}

function runDispatchCommand(command, payload) {
  const argv = Array.isArray(command) ? command : [command];
  return new Promise((resolve, reject) => {
    const child = spawn(argv[0], argv.slice(1), { stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`standalone dispatch command failed (${code}): ${stderr || stdout}`));
        return;
      }
      try {
        resolve(stdout.trim() ? JSON.parse(stdout) : {});
      } catch (error) {
        reject(error);
      }
    });
    child.stdin.end(JSON.stringify(stripUndefined(payload)));
  });
}

function normalizeLaunchRequestId(result) {
  if (typeof result === 'string' && result) {
    return result;
  }
  const launchRequestId = result?.launch_request_id ?? result?.launchRequestId ?? result?.dispatchId;
  if (!launchRequestId) {
    throw new Error('standalone dispatch did not return a launch request id');
  }
  return launchRequestId;
}

function workflowActionNamespace(call) {
  return {
    run: {
      create: (payload) => call('workflow.run.create', payload),
      replay: (payload) => call('workflow.run.replay', payload),
      cancel: (payload) => call('workflow.run.cancel', payload),
    },
    trigger: {
      fire: (payload) => call('workflow.trigger.fire', payload),
    },
    dispatch: {
      cancel: (payload) => call('dispatch.cancel', payload),
    },
  };
}

export function deriveWorkflowActionId({
  workflow_id,
  workflow_version,
  requested_action,
  launch_intent_or_target_run_or_step,
  operator_principal,
  request_id,
}) {
  const keyParts = [
    workflow_id,
    workflow_version,
    requested_action,
    launch_intent_or_target_run_or_step,
    operator_principal,
  ];
  if (requested_action === 'workflow.run.replay') {
    if (!request_id) {
      throw new Error('workflow.run.replay action id derivation requires request_id');
    }
    keyParts.push(request_id);
  }
  const canonical = ensureAsciiJsonString(JSON.stringify(keyParts));
  return `wfa_${createHash('sha256').update(canonical).digest('hex')}`;
}

function ensureAsciiJsonString(value) {
  return value.replace(/[^\x00-\x7f]/g, (char) => {
    const codeUnit = char.charCodeAt(0).toString(16).padStart(4, '0');
    return `\\u${codeUnit}`;
  });
}

function normalizeWorkflowActionPayload(appId, operation, payload) {
  const requestId = requireWorkflowActionString(payload, 'request_id');
  const workflowId = requireWorkflowActionString(payload, 'workflow_id');
  const workflowVersion = payload.workflow_version ?? payload.version;
  if (!workflowVersion) {
    throw new Error('workflow action requires workflow_version');
  }
  const operatorPrincipal = requireWorkflowActionString(payload, 'operator_principal');
  const launchOrTarget = LAUNCH_INTENT_OPERATIONS.has(operation) ? requestId : targetRunOrStep(payload, operation);
  const actionId = deriveWorkflowActionId({
    workflow_id: workflowId,
    workflow_version: String(workflowVersion),
    requested_action: operation,
    launch_intent_or_target_run_or_step: launchOrTarget,
    operator_principal: operatorPrincipal,
    request_id: requestId,
  });
  return {
    app_id: appId,
    request_id: requestId,
    workflow_id: workflowId,
    workflow_version: String(workflowVersion),
    requested_action: operation,
    launch_intent_or_target_run_or_step: launchOrTarget,
    operator_principal: operatorPrincipal,
    action_id: actionId,
    payload: stripUndefined({ ...payload, operation }),
  };
}

function workflowActionResponse(normalized, terminal) {
  const response = {
    app_id: normalized.app_id,
    request_id: normalized.request_id,
    action_id: normalized.action_id,
    state: terminal.state,
    workflow_id: normalized.workflow_id,
    workflow_version: normalized.workflow_version,
    requested_action: normalized.requested_action,
    launch_intent_or_target_run_or_step: normalized.launch_intent_or_target_run_or_step,
    operator_principal: normalized.operator_principal,
    audit_ref: `standalone://audit/workflow-action/${normalized.app_id}/${normalized.action_id}`,
  };
  if (terminal.result) {
    response.result = terminal.result;
    response.audit_ref = terminal.result.audit_ref ?? response.audit_ref;
  }
  if (terminal.manual_reconciliation) {
    response.manual_reconciliation = terminal.manual_reconciliation;
    response.audit_ref = terminal.manual_reconciliation.audit_ref ?? response.audit_ref;
  }
  return response;
}

function validateWorkflowActionOperation(operation) {
  if (!WORKFLOW_ACTION_OPERATIONS.has(operation)) {
    throw new Error(`unsupported workflow action operation: ${operation}`);
  }
}

function requireWorkflowActionString(payload, key) {
  if (!payload?.[key]) {
    throw new Error(`workflow action requires ${key}`);
  }
  return String(payload[key]);
}

function targetRunOrStep(payload, operation) {
  const keys = operation === 'dispatch.cancel'
    ? ['dispatch_id', 'launch_request_id', 'target_run_or_step']
    : ['target_run_or_step', 'target_run_id', 'target_step_id', 'run_id', 'step_id', 'dispatch_id'];
  for (const key of keys) {
    if (payload?.[key]) {
      return String(payload[key]);
    }
  }
  throw new Error('workflow action requires target_run_or_step');
}

function requireRequestId(payload) {
  if (!payload?.request_id) {
    throw new Error('dispatch requires request_id');
  }
  return payload.request_id;
}

function topicMatches(pattern, topic) {
  if (pattern === topic || pattern === '*') {
    return true;
  }
  if (!pattern.includes('*')) {
    return false;
  }
  const escaped = pattern.split('*').map(escapeRegExp).join('.*');
  return new RegExp(`^${escaped}$`).test(topic);
}

function validateAppId(appId) {
  if (!APP_ID_RE.test(appId) || appId.includes('..')) {
    throw new Error('invalid app_id: use lowercase letters, digits, dot, underscore, or dash; slash and .. are forbidden');
  }
}

function pathInside(child, parent) {
  const rel = relative(parent, child);
  return rel === '' || (!!rel && !rel.startsWith('..') && !isAbsolute(rel));
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function trimTrailingSlash(value) {
  return String(value).replace(/\/+$/, '');
}

function stripUndefined(value) {
  return Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined));
}
