export interface ProducerContracts {
  contractVersion: string;
  exportCommand: string;
  statusVocabulary: { statuses: string[]; terminal: string[]; succeeded: string[]; [key: string]: unknown };
  producers: Record<string, {
    schema: Record<string, any>;
    examples: { scenario: string; value: any; [key: string]: unknown }[];
    [key: string]: unknown;
  }>;
  [key: string]: unknown;
}
export function parseProducerContracts(text: string): ProducerContracts;
