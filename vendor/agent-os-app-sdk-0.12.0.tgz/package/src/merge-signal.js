import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';

/** Capture an already observed merge through the OS owner. Never merges a PR. */
export async function recordMergeSignal(payload, options = {}) {
  if (!Number.isInteger(payload.pr_number) || payload.pr_number <= 0
    || !/^(?:[a-fA-F0-9]{40}|[a-fA-F0-9]{64})$/.test(payload.merge_commit_sha ?? '')
    || !['merge', 'squash', 'rebase'].includes(payload.mode)) throw new Error('invalid merge observation');
  const args = ['build-completions', 'record-merge'];
  for (const key of ['hq_root', 'pr_number', 'merge_commit_sha', 'launch_request_id', 'ticket_ref', 'merged_by', 'mode']) {
    if (payload[key] != null) args.push('--' + key.replaceAll('_', '-'), String(payload[key]));
  }
  try {
    const {stdout} = await (options.execFile ?? promisify(execFile))(options.hq_bin ?? 'hq', args,
      {env:options.env ?? process.env,timeout:options.timeout_ms ?? 15000,maxBuffer:1024 * 1024});
    const result = JSON.parse(stdout);
    if (result.status !== 'recorded' || !result.event_id) throw new Error('capture failed');
    return result;
  } catch { throw new Error('merge completion capture unavailable'); }
}

/** Advisory routing evidence through the existing OS owner; never dispatches. */
export async function readRemediatorProposal(payload, options = {}) {
  if (!['hammer','remediator'].includes(payload?.kind) || typeof payload.repo !== 'string'
    || !Number.isInteger(payload.prNumber) || payload.prNumber <= 0) throw new Error('invalid proposal selector');
  const input = JSON.stringify({kind:payload.kind,repo:payload.repo,prNumber:payload.prNumber});
  if (input.length > 8192) throw new Error('invalid proposal selector');
  return new Promise((resolve,reject)=>{
    const child = spawn(options.hq_bin ?? 'hq',['osg','remediator-proposal'],
      {env:options.env ?? process.env,stdio:['pipe','pipe','ignore']});
    const deadline = setTimeout(()=>child.kill('SIGKILL'),options.timeout_ms ?? 15000);
    deadline.unref?.();
    let stdout='';
    child.stdout.on('data',data=>{stdout+=data;if(stdout.length>131072) child.kill('SIGKILL');});
    child.on('error',()=>{clearTimeout(deadline);reject(new Error('remediator proposal unavailable'));});
    child.stdin.on('error',()=>{});
    child.on('close',code=>{
      clearTimeout(deadline);
      try { if(code!==0) throw Error(); const value=JSON.parse(stdout);
        if(typeof value?.reason!=='string') throw Error(); resolve(value);
      } catch { reject(new Error('remediator proposal unavailable')); }
    });
    child.stdin.end(input);
  });
}
