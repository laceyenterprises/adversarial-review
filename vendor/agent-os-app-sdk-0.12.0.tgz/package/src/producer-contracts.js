// Offline consumption of the public `hq api spec --surface producer-contracts`
// JSON. No producer imports, subprocesses, filesystem or network access.
export function parseProducerContracts(text) {
  const bundle = JSON.parse(text);
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  if (!object(bundle) || typeof bundle.contractVersion !== 'string'
      || !/^1\.[0-9]+$/.test(bundle.contractVersion)) {
    throw new Error('producer-contracts: unsupported or missing contractVersion; expected major 1');
  }
  if (!object(bundle.producers) || !object(bundle.statusVocabulary)
      || !['statuses', 'terminal', 'succeeded'].every(key =>
        Array.isArray(bundle.statusVocabulary[key])
        && bundle.statusVocabulary[key].every(value => typeof value === 'string'))) {
    throw new Error('producer-contracts: invalid producers or statusVocabulary');
  }
  for (const [name, producer] of Object.entries(bundle.producers)) {
    if (!object(producer) || !object(producer.schema) || !Array.isArray(producer.examples)) {
      throw new Error(`producer-contracts: invalid producer ${name}`);
    }
  }
  return bundle;
}
