export * from './producer-readers.js';
export { parseProducerContracts } from './producer-contracts.js';
export type { ProducerContracts } from './producer-contracts.js';

// Existing session APIs retain their open option/result shapes. The 0.3.0
// producer readers above provide evidence-specific types without narrowing them.
export function connect(options?: Record<string, any>): Promise<AppSession>;
export class HealthRouter {
  constructor(options?: Record<string, any>);
  [key: string]: any;
}
export function deriveWorkflowActionId(options: Record<string, any>): string;

/** SDK 0.4.0: read-only evidence for a request owned by the session app. */
export type HostServicesResult =
  | { schema_version: 1; status: 'found'; data: Record<string, unknown> }
  | { schema_version: 1; status: 'not_found' }
  | { schema_version: 1; status: 'unavailable'; reason: string };
export interface EvalUsageOptions {
  view?: 'runs' | 'controls' | 'transcript_metrics' | 'calibration' | 'zero_token' | 'token_samples';
  run_id?: string;
  worker_class?: string;
  since?: string;
  limit?: number;
  offset?: number;
}
export interface EvalPage {
  limit: number;
  offset: number;
  has_more: boolean;
  next_offset: number | null;
  truncated: boolean;
}
export interface EvalUsageResult {
  schema_version: 1;
  status: 'found' | 'not_found' | 'unavailable';
  reason?: string;
  app_id?: string;
  request_id?: string;
  launch?: Record<string, unknown>;
  items?: Array<Record<string, unknown>>;
  page?: EvalPage;
  cost?: Record<string, number | null> | null;
  usage?: Record<string, number | boolean | null> | null;
  aggregate_complete?: boolean;
  retry?: { status: 'found' | 'unavailable'; reason: string | null; policy: { maxAttempts?: number | null; backoffSeconds?: number | null } | null };
  acceptance?: { launch_request_id: string; launches: Array<{workerId: unknown; idempotencyKey: unknown}>; workers: Array<Record<string, unknown>>; complete: boolean; reason: string | null; historical_absence_proven: false; logical_ownership_checked: false; process_history_checked: false };
  certificate?: { kind: 'proven-zero'; reason: string; launch_request_id: string } | null;
  evidence?: Record<string, unknown>;
  [key: string]: unknown;
}
/** Producer-owned v1 outcomes. session_ref is opaque; acceptance is not delivery. */
export interface NativeResumeOutcome {
  contract_version: 1;
  mode: 'native';
  reason: 'eligible';
  launch_request_id: string;
  session_ref: string;
}
export interface FreshResumeOutcome {
  contract_version: 1;
  mode: 'fresh';
  reason: 'native-unavailable' | 'native-state-expired' | 'native-mode-unsupported';
  launch_request_id: string;
  session_ref: string | null;
}
export type ResumeOutcome = NativeResumeOutcome | FreshResumeOutcome;
export interface ResumeReceipt {
  contract_version: 1;
  state: 'pending';
  operation_id: string;
  launch_request_id: string;
}
export interface ResumeOptions {
  idempotency_key?: string;
  waitTimeoutMs?: number;
  requestTimeoutMs?: number;
  pollIntervalMs?: number;
  transportRetries?: number;
}
export class ResumeError extends Error {
  constructor(payload: Record<string, any>, idempotencyKey: string, httpStatus?: number | null);
  payload: Record<string, any>;
  code: string;
  producer: string;
  reason: string;
  field: string | null;
  retryable: boolean;
  idempotency_key: string;
  http_status: number | null;
  receipt?: ResumeReceipt | null;
}
export class ResumePending extends ResumeError {
  constructor(receipt: ResumeReceipt, idempotencyKey: string);
  receipt: ResumeReceipt;
}
export interface DispatchLookupSelector {
  launch_request_ids?: string[];
  idempotency_key?: string;
  ticket_ref?: string;
  requested_at_or_after?: string;
  include_retry_chain?: boolean;
}
export interface DispatchLookupResult {
  schema_version: 1;
  status: 'found' | 'not_found' | 'not_live' | 'unavailable';
  complete?: boolean;
  roots?: string[];
  items?: Array<Record<string, unknown>>;
  retry_edges?: Array<{ parent: string; child: string }>;
  reason?: string;
}
export function readHcpDispatchLookup(selector: DispatchLookupSelector | WorkerObservationSelector, options?: { token?: string; token_path?: string; endpoint_url?: string; request_timeout_ms?: number }): Promise<DispatchLookupResult>;
export interface DispatchReadSessionOptions {
  session_token: string;
  endpoint_url?: string;
  request_timeout_ms?: number;
}
export function readSessionDispatchLookup(selector: DispatchLookupSelector | WorkerObservationSelector, options: DispatchReadSessionOptions): Promise<DispatchLookupResult>;
export function readDispatchLookupSync(selector: DispatchLookupSelector | WorkerObservationSelector, options: DispatchReadSessionOptions): DispatchLookupResult;
export interface AppSession {
  dispatchLookup(selector: DispatchLookupSelector | WorkerObservationSelector): Promise<DispatchLookupResult>;
  resume(lrqId: string, prompt: string, options?: ResumeOptions): Promise<ResumeOutcome>;
  hostServices(action: string, options?: Record<string, unknown>): Promise<HostServicesResult>;
  evalUsage(requestId: string, options?: EvalUsageOptions): Promise<EvalUsageResult>;
  evalRequests(options?: Pick<EvalUsageOptions, 'limit' | 'offset'>): Promise<EvalUsageResult>;
  [key: string]: any;
}

export function readDispatchLookupResult(value: unknown): { available: boolean; found?: boolean; reason?: string; items?: Array<Record<string, any>>; roots?: string[]; retryEdges?: Array<{parent: string; child: string}> };
export function dispatchRetryDescendants(items: Array<Record<string, any>>, edges: Array<{parent: string; child: string}>, launchRequestId: string): Array<Record<string, any>>;

/** Passed to dispatchLookup; authorization remains bound to the session's app. */
export interface WorkerObservationSelector extends DispatchLookupSelector {
  observation: 'workers' | 'sessions' | 'provenance' | 'completions' | 'dag_runs' | 'execution_verdicts' | 'hardening_contracts' | 'hardening_records' | 'hardening_exposure';
  signal_kind?: string;
  plan_id?: string;
  states?: string[];
  contract_id?: string;
  pr_number?: number;
  builder_identity?: boolean;
  head_sha?: string;
  launch_request_id?: string;
  worker_run_id?: string;
  session_keys?: string[];
  repo?: string;
  branch?: string;
  limit?: number;
  offset?: number;
}
export function readWorkerObservations(value: unknown): { available: boolean; found?: boolean; notLive?: true; reason?: string; items?: Array<Record<string, any>>; complete?: boolean; nextOffset?: number | null; scopeComplete?: false; mutationAuthority?: false };

export function readWorkerObservationsSync(selector: WorkerObservationSelector, options: Record<string, any> & { session_token: string }): DispatchLookupResult;

export interface WorkerProcessObservation {
  worker_process_id: string;
  launch_request_id: string;
  runtime_session_id: string | null;
  pid: number | null;
  process_status: string | null;
  started_at: string | null;
  last_observed_at: string | null;
  exited_at: string | null;
  updated_at: string | null;
}
export interface WorkerRunObservation {
  run_id: string;
  launch_request_id: string;
  session_id: string | null;
  status: string | null;
  process: WorkerProcessObservation | null;
  process_match: 'session' | 'launch' | null;
  liveness: 'unknown';
  mutation_authority: false;
  token_usage_input: number | null;
  token_usage_output: number | null;
  token_usage_guardrail: number | null;
  token_usage_cost_usd: number | null;
  total_cache_read_tokens: number | null;
  total_cache_write_tokens: number | null;
  usage_known: boolean;
  usage_partial: boolean;
}
export interface RuntimeSessionObservation {
  session_id: string;
  adapter_session_key: string | null;
  total_input_tokens: number | null;
  total_output_tokens: number | null;
  total_cache_read_tokens: number | null;
  total_cache_write_tokens: number | null;
  total_cost_usd: number | null;
}

export const readReviewObservations: typeof readWorkerObservations;

export function recordMergeSignal(payload: { pr_number: number; merge_commit_sha: string; mode: "merge" | "squash" | "rebase"; hq_root?: string; launch_request_id?: string; ticket_ref?: string; merged_by?: string }, options?: Record<string, any>): Promise<{status: "recorded"; event_id: string}>;

export function readRemediatorProposal(payload: { kind: "hammer" | "remediator"; repo: string; prNumber: number }, options?: Record<string, any>): Promise<Record<string, any>>;
