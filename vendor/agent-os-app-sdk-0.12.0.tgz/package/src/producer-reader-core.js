// Offline evidence readers. No producer imports, Node built-ins or caller
// routing policy, so the browser entry (browser.js) shares this module.
import { parseProducerContracts } from './producer-contracts.js';
import { producerContractsV1 } from './producer-contracts-v1.js';

export const bundle = parseProducerContracts(producerContractsV1);
export const LAUNCH_REQUEST_STATUSES = new Set(bundle.statusVocabulary.statuses);
export const TERMINAL_LAUNCH_REQUEST_STATUSES = new Set(bundle.statusVocabulary.terminal);
export const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

/** @param {unknown} value @returns {string} */
export function diagnosticValue(value) {
  let text;
  try { text = JSON.stringify(value) ?? String(value); }
  catch { text = '[unserializable]'; }
  return text.length > 200 ? `${text.slice(0, 199)}…` : text;
}

/** @param {unknown[]} values @returns {string[]} */
export function boundedDiagnostics(values) {
  const result = new Set();
  for (const value of values || []) {
    if (typeof value !== 'string' || !value) continue;
    result.add(value.length > 500 ? `${value.slice(0, 499)}…` : value);
    if (result.size === 20) break;
  }
  return [...result];
}

/** @param {unknown} value
 * @returns {{status: string|null, terminal: boolean, succeeded: boolean, blockedNeedsDecision: boolean, diagnostic: string|null}} */
export function readLaunchRequestStatus(value) {
  const known = typeof value === 'string' && LAUNCH_REQUEST_STATUSES.has(value);
  return {
    status: known ? value : null,
    terminal: known && TERMINAL_LAUNCH_REQUEST_STATUSES.has(value),
    succeeded: value === 'succeeded',
    blockedNeedsDecision: value === 'blocked_needs_decision',
    diagnostic: known ? null : `session_ledger: launch_requests.status ${value == null ? 'missing' : `unrecognized value ${JSON.stringify(value)}`}`,
  };
}

// The exported producer schemas own field and state vocabulary. This focused
// walker covers their structural subset; it is not an admission validator.
export function projectionDiagnostics(value, schema, path, producer) {
  const note = message => [`${producer}: ${path ? `${path} ` : ''}${message}`];
  if (schema.anyOf) {
    const choices = schema.anyOf.map(choice => projectionDiagnostics(value, choice, path, producer));
    return choices.some(choice => !choice.length) ? [] : choices[0];
  }
  const type = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
  const types = [].concat(schema.type || []);
  if (types.length && !types.includes(type) && !(types.includes('integer') && Number.isInteger(value))) return note(`missing/invalid ${types.join('|')}`);
  if (schema.enum && !schema.enum.includes(value)) return note(`unrecognized value ${diagnosticValue(value)}`);
  const diagnostics = [];
  if (object(value)) {
    for (const key of schema.required || []) {
      if (!Object.hasOwn(value, key)) diagnostics.push(`${producer}: ${path}.${key} missing`);
    }
    for (const [key, item] of Object.entries(value)) {
      const child = schema.properties?.[key] || (object(schema.additionalProperties) ? schema.additionalProperties : null);
      if (child) diagnostics.push(...projectionDiagnostics(item, child, `${path}.${key}`, producer));
    }
    if (value.available === false || value.complete === false) diagnostics.push(`${producer}: ${path} evidence unavailable/incomplete`);
    for (const message of Array.isArray(value.diagnostics) ? value.diagnostics : []) {
      if (typeof message === 'string') diagnostics.push(`${producer}: ${path}.diagnostics: ${message}`);
    }
    if (typeof value.unavailableReason === 'string') diagnostics.push(`${producer}: ${path}.unavailableReason: ${value.unavailableReason}`);
  } else if (Array.isArray(value) && schema.items) {
    value.forEach((item, index) => diagnostics.push(...projectionDiagnostics(item, schema.items, `${path}[${index}]`, producer)));
  }
  return diagnostics;
}
