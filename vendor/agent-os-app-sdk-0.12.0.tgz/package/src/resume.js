// Bounded app resume transport. The producer owns admission, mode and native bind.
import { randomUUID } from 'node:crypto';
import { producerContractsV1 } from './producer-contracts-v1.js';

const PRODUCERS = JSON.parse(producerContractsV1).producers;

export class ResumeError extends Error {
  constructor(payload, idempotencyKey, httpStatus = null) {
    super(`${payload.producer ?? 'app-sdk/resume'} ${payload.error}: ${payload.reason}`);
    this.name = 'ResumeError';
    this.payload = payload;
    this.code = payload.error;
    this.producer = payload.producer ?? 'app-sdk/resume';
    this.reason = payload.reason;
    this.field = payload.field ?? null;
    this.retryable = payload.retryable ?? false;
    this.idempotency_key = idempotencyKey;
    this.http_status = httpStatus;
  }
}

export class ResumePending extends ResumeError {
  constructor(receipt, idempotencyKey) {
    super({ error: 'resume_pending', reason: 'wait-deadline', retryable: true }, idempotencyKey);
    this.name = 'ResumePending';
    this.receipt = receipt;
  }
}

function localError(code, reason, key) {
  return new ResumeError({ error: code, reason, retryable: code === 'resume_transport' }, key);
}

export function resumeUnavailable(options = {}) {
  return localError('resume_unavailable', 'resume-requires-agent-os', options?.idempotency_key ?? '');
}

const opaque = value => typeof value === 'string' && /^[A-Za-z0-9_-]+$/.test(value);

function validate(value, surface, key) {
  const schema = PRODUCERS[surface].schema;
  let valid = value && typeof value === 'object' && !Array.isArray(value)
    && schema.required.every(field => Object.hasOwn(value, field)) && value.contract_version === 1;
  if (valid && surface === 'resume-error') {
    valid = value.producer === schema.properties.producer.const
      && schema.properties.error.enum.includes(value.error)
      && schema.properties.field.enum.includes(value.field)
      && typeof value.retryable === 'boolean'
      && typeof value.reason === 'string' && value.reason.trim().length > 0;
  } else if (valid) {
    valid = opaque(value.launch_request_id);
    if (surface === 'resume-pending') {
      valid = valid && value.state === 'pending' && opaque(value.operation_id);
    } else {
      const native = value.mode === 'native';
      const reasons = schema.allOf[0][native ? 'then' : 'else'].properties.reason;
      valid = valid && schema.properties.mode.enum.includes(value.mode)
        && (native ? [reasons.const] : reasons.enum).includes(value.reason)
        && (opaque(value.session_ref) || (!native && value.session_ref === null));
    }
  }
  if (!valid) throw localError('resume_bad_response', `${surface}: invalid producer receipt`, key);
}

export async function resume(endpoint, token, lrqId, prompt, options = {}) {
  const opts = options ?? {};
  const allowed = ['idempotency_key', 'waitTimeoutMs', 'requestTimeoutMs', 'pollIntervalMs', 'transportRetries'];
  if (Object.keys(opts).some(key => !allowed.includes(key))) {
    throw new TypeError('resume accepts only transport and idempotency options');
  }
  const key = opts.idempotency_key ?? randomUUID();
  if (!opaque(lrqId) || typeof prompt !== 'string' || !prompt.trim()) {
    throw new TypeError('resume requires an explicit LRQ ID and nonempty prompt');
  }
  if (typeof key !== 'string' || !key.trim()) throw new TypeError('resume requires a nonempty idempotency_key');
  const wait = opts.waitTimeoutMs ?? 30_000;
  const requestTimeout = opts.requestTimeoutMs ?? 10_000;
  const interval = opts.pollIntervalMs ?? 250;
  if ([wait, requestTimeout, interval].some(value => !Number.isFinite(value) || value <= 0 || value > 2_147_483_647)) {
    throw new TypeError('resume timeouts and poll interval must be positive finite timer values');
  }
  const retries = opts.transportRetries ?? 1;
  if (!Number.isInteger(retries) || retries < 0 || retries > 3) throw new TypeError('resume transportRetries must be an integer from 0 to 3');
  const deadline = performance.now() + wait;
  let receipt = null;
  let failures = 0;
  const body = JSON.stringify({ lrq_id: lrqId, prompt, idempotency_key: key });
  while (true) {
    const remaining = deadline - performance.now();
    if (remaining <= 0) {
      if (receipt) throw new ResumePending(receipt, key);
      throw localError('resume_transport', 'wait-deadline-before-receipt', key);
    }
    const url = receipt
      ? `${endpoint}/v1/resume_status?${new URLSearchParams({ operation_id: receipt.operation_id })}`
      : `${endpoint}/v1/resume`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Math.min(remaining, requestTimeout));
    let response, value;
    try {
      response = await fetch(url, {
        method: receipt ? 'GET' : 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        ...(receipt ? {} : { body }), signal: controller.signal, redirect: 'error',
      });
      const text = await response.text();
      try { value = JSON.parse(text); }
      catch { throw localError('resume_bad_response', 'invalid producer JSON', key); }
    } catch (error) {
      if (error instanceof ResumeError) throw error;
      if (receipt && (performance.now() >= deadline || (controller.signal.aborted && remaining <= requestTimeout))) {
        throw new ResumePending(receipt, key);
      }
      if (failures >= retries) {
        const failure = localError('resume_transport', 'response-unavailable', key);
        failure.receipt = receipt;
        throw failure;
      }
      failures += 1;
      clearTimeout(timer);
      await new Promise(resolve => setTimeout(resolve, Math.min(interval, Math.max(0, deadline - performance.now()))));
      continue;
    } finally {
      clearTimeout(timer);
    }
    if (response.status !== 200 && response.status !== 202) {
      validate(value, 'resume-error', key);
      throw new ResumeError(value, key, response.status);
    }
    validate(value, response.status === 202 ? 'resume-pending' : 'resume-outcome', key);
    if (response.status === 200) {
      if (receipt && value.launch_request_id !== receipt.launch_request_id) {
        throw localError('resume_bad_response', 'pending identity changed', key);
      }
      return value;
    }
    if (receipt && (value.operation_id !== receipt.operation_id || value.launch_request_id !== receipt.launch_request_id)) {
      throw localError('resume_bad_response', 'pending identity changed', key);
    }
    receipt = value;
    failures = 0;
    await new Promise(resolve => setTimeout(resolve, Math.min(interval, Math.max(0, deadline - performance.now()))));
  }
}
